using Application;
using Application.Persistence.DG;
using Application.Persistence.FTBEmployee;
using Application.Persistence.SCR;
using Application.Services.Auth;
using Application.Settings;
using BlazorServerUI.Auth;
using BlazorServerUI.Exceptions;
using BlazorServerUI.Features;
using BlazorServerUI.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;
using PACT.CyberArk.ApiClient;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.MSSqlServer;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);
var configuration = builder.Configuration;
var environment = builder.Environment;
// Add services to the container.

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
    .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
    .Enrich.FromLogContext()
    .WriteTo.MSSqlServer(
    connectionString: configuration.GetConnectionString("AppConnectionString"),
    sinkOptions: new MSSqlServerSinkOptions
    {
        TableName = "Logs",
        SchemaName = "SCR",
        AutoCreateSqlTable = false
    })
    .CreateLogger();
builder.Host.UseSerilog();
builder.Services.AddMemoryCache();
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<GlobalHttpExceptionHandler>();
builder.AddPactCyberArkApiClient();

builder.Services.AddMudServices(config =>
{
    config.SnackbarConfiguration.PositionClass = Defaults.Classes.Position.TopRight;
    config.SnackbarConfiguration.PreventDuplicates = false;
    config.SnackbarConfiguration.NewestOnTop = false;
    config.SnackbarConfiguration.ShowCloseIcon = true;
    config.SnackbarConfiguration.SnackbarVariant = Variant.Filled;
});
builder.Services.Configure<RazorPagesOptions>(options => options.RootDirectory = "/Features");

builder.Services.AddApplicationServices(environment.EnvironmentName);
builder.Services.Configure<AppSetting>(builder.Configuration.GetSection("AppSettings"));
builder.Services.Configure<UploadFileSetting>(builder.Configuration.GetSection("UploadFileSettings"));
builder.Services.Configure<SharePointSetting>(builder.Configuration.GetSection("SharePointSettings"));
builder.Services.Configure<EmailSetting>(builder.Configuration.GetSection("EmailSettings"));
builder.Services.Configure<CyberArkSetting>(builder.Configuration.GetSection("CyberArkSettings"));
builder.Services.Configure<ActiveDirectorySetting>(builder.Configuration.GetSection("ActiveDirectorySettings"));
builder.Services.Configure<Microsoft.AspNetCore.SignalR.HubOptions>(options =>
{
    options.MaximumReceiveMessageSize = 20 * 1024 * 1024;
});
builder.Services.AddDbContext<SCRContext>(options =>
{
    if (environment.IsDevelopment())
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString")).EnableSensitiveDataLogging();
    }
    else
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString"));
    }
}, ServiceLifetime.Transient, ServiceLifetime.Transient);


builder.Services.AddDbContext<FTBEmployeeContext>(options =>
{
    if (environment.IsDevelopment())
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString")).EnableSensitiveDataLogging();
    }
    else
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString"));
    }
}, ServiceLifetime.Transient, ServiceLifetime.Transient);

builder.Services.AddDbContext<DGPropertiesContext>(options =>
{
    if (environment.IsDevelopment())
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString")).EnableSensitiveDataLogging();
    }
    else
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString"));
    }
}, ServiceLifetime.Transient, ServiceLifetime.Transient);

builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
   .AddNegotiate();

builder.Services.AddAuthorization(options =>
{
    // By default, all incoming requests will be authorized according to the default policy.
    options.FallbackPolicy = options.DefaultPolicy;
});
builder.Services.AddTransient<IAuthService, BlazorAuthService>();     //AddScoped
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<IPlatformUserService, WindowPlatformUserService>();
builder.Services.AddScoped<IRoleTransformationService, RoleTransformationService>();
builder.Services.AddScoped<IClaimsTransformation, CustomClaimTransformation>();
builder.Services.AddAuthorizationCore(config =>
{
    config.AddPolicy(AppPolicy.CanCreateRequest, policy =>
    {
        policy.RequireClaim(ClaimTypes.Role, AppRoleName.Admin);
    });
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    //app.UseExceptionHandler("/Error", createScopeForErrors: true);
    //app.UseDeveloperExceptionPage();
    app.UseExceptionHandler();
    app.UseHsts();
}
else
{
    //app.UseDeveloperExceptionPage();
    app.UseExceptionHandler();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
