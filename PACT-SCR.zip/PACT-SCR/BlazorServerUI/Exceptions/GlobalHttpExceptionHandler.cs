﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace BlazorServerUI.Exceptions
{
    public class GlobalHttpExceptionHandler : IExceptionHandler
    {
        private readonly ILogger<GlobalHttpExceptionHandler> _logger;

        public GlobalHttpExceptionHandler(ILogger<GlobalHttpExceptionHandler> logger)
        {
            _logger = logger;
        }
        public async ValueTask<bool> TryHandleAsync(
            HttpContext httpContext,
            Exception exception,
            CancellationToken cancellationToken)
        {
            _logger.LogError(exception, "Unhandled HTTP exception");
            httpContext.Response.StatusCode = StatusCodes.Status500InternalServerError;

            await httpContext.Response.WriteAsJsonAsync
                (
                new ProblemDetails
                {
                    Status = StatusCodes.Status500InternalServerError,
                    Title =  "Unexpected error occurred.",
                    Detail = "An unexpected error occured."
                }, cancellationToken);
            return true;
        }
    }
}
