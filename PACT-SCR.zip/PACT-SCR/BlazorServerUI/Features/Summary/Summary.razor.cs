﻿using Application.Common.Lookups;
using Application.DTOs.Request;
using Application.Features.Requests.Commands;
using Application.Features.Requests.Queries;
using Application.Services.Attachment;
using Application.Services.Auth;
using Application.Services.FtbEmployee;
using Application.Settings;
using BlazorServerUI.Auth;
using BlazorServerUI.Extensions;
using BlazorServerUI.Features.Common;
using Microsoft.Extensions.Options;
namespace BlazorServerUI.Features.Summary
{
    public partial class Summary : ComponentBase
    {
        [CascadingParameter] private Task<AuthenticationState> authenticationStateTask { get; set; } = default!;
        [Inject] IAuthService AuthService { get; set; } = default!;
        [Inject] IDialogService DialogService { get; set; } = default!;
        [Inject] CertifyRequestCommand CertifyRequestCommand { get; set; } = default!;
        [Inject] CancelRequestCommand CancelRequestCommand { get; set; } = default!;
        [Inject] UpdateRequestNoteCommand UpdateRequestNoteCommand { get; set; } = default!;
        [Inject] GetAllRequestsQuery GetAllRequestsQuery { get; set; } = default!;
        [Inject] FtbEmployeeService FtbEmployeeService { get; set; } = default!;
        [Inject] IAttachmentService AttachmentService { get; set; } = default!;
        [Inject] IOptions<AppSetting> AppSettings { get; set; } = default!;
        [Inject] ISnackbar Snackbar { get; set; } = default!;
        private List<RequestSummaryDTO>? Requests = new();
        private List<RequestSummaryDTO>? RequestsToDisplay = new();
        private RequestSummaryDTO selectedItem = null!;
        private SortDirection sortDirection = SortDirection.Ascending;
        private string searchString = "";
        private bool isCertifying = false;
        private bool isCanceling = false;
        private string? currentUserFtbId;
        private string? currentUserEmail;
        private bool isAdmin;
        private string? selectedStatus;
        protected override async Task OnInitializedAsync()
        {
            _ = AttachmentService.PreConfigSharepointApiAsync();

            currentUserFtbId = await AuthService.GetUserFtbId();
            currentUserEmail = await GetCurrentUserEmailByFtbIdAsync(currentUserFtbId);
            var user = (await authenticationStateTask).User;
            isAdmin = user.IsInRole(AppRoleName.Admin);

            Requests = await GetAllRequestsQuery.HandleAsync();
            if (isAdmin)
            {
                Requests = Requests.OrderBy(x => x.Id).ToList();
            }
            else
            {
                Requests = Requests.Where(CanCurrentUserAccessRequest)
                                   .OrderBy(x => x.Id)
                                   .ToList();
            }
        }

        private async Task<string?> GetCurrentUserEmailByFtbIdAsync(string ftbId)
        {
            var employee = await FtbEmployeeService.GetEmployeeByIdAsync(ftbId);
            return employee?.Email;
        }

        private bool CanCurrentUserAccessRequest(RequestSummaryDTO request)
        {
            return string.Equals(request.FtbId, currentUserFtbId, StringComparison.OrdinalIgnoreCase)
                || IsCurrentUserInServerTeam(request);
        }

        private bool IsCurrentUserInServerTeam(RequestSummaryDTO request)
        {
            if(string.IsNullOrWhiteSpace(currentUserEmail))
                return false;

            return request.ServerTeams.Any(email => string.Equals(email?.Trim(), currentUserEmail.Trim(), StringComparison.OrdinalIgnoreCase));
        }

        private Color GetStatusColor(string? status) => status == StatusLookup.Open.ToString() ? Color.Success : status == StatusLookup.Cancelled.ToString() ? Color.Dark : Color.Info;
        private Color GetCerfifyButtonColor(string? status) => status == StatusLookup.Open.ToString() ? Color.Primary : Color.Secondary;
        private bool CanCertify(string? status) => status != StatusLookup.Open.ToString();
        private bool CanCancel(string? status) => status == StatusLookup.Open.ToString();
        private bool CanAddNote(string? status) => status == StatusLookup.Open.ToString() || status == StatusLookup.Closed.ToString() || status == StatusLookup.Cancelled.ToString();
        private string CertifyButtonText(string? status) => status == StatusLookup.Closed.ToString() ? "Certified" : "Certify";
        private void SetStatusFilter(string? status)
        {
            selectedStatus = status;
        }
        private async Task CertifyAsync(int requestId, string fsTicketId)
        {

            bool? dialogResult = await DialogService.ShowMessageBox(
                title: "Confirm",
                markupMessage: (MarkupString)"Are you sure you want to certify this request?",
                yesText: "Yes, Certify",
                noText: "Cancel");

            if (dialogResult != true)
                return;

            if (isCertifying)
                return;

            isCertifying = true;
            StateHasChanged();

            var certifyRequestData = new CertifyRequestCommandData(requestId);
            var certifyResult = await CertifyRequestCommand.HandleAsync(certifyRequestData);
            if (!certifyResult.IsSuccess)
            {
                Snackbar.ShowResult(certifyResult, "Failed to certify request. Please try again");
                isCertifying = false;
                StateHasChanged();
                return;
            }

            var selectedRow = Requests.FirstOrDefault(x => x.Id == requestId);
            if (selectedRow != null)
            {
                selectedRow.Status = StatusLookup.Closed.ToString();
                selectedRow.CloseDate ??= DateTime.UtcNow;
            }

            isCertifying = false;
            StateHasChanged();

        }
        private async Task CancelAsync(int requestId)
        {
            bool? dialogResult = await DialogService.ShowMessageBox(
            title: "Confirm",
            markupMessage: (MarkupString)"Are you sure you want to cancel(unresolve) this request?",
            yesText: "Yes, Cancel",
            noText: "Cancel");

            if (dialogResult != true)
                return;


            if (isCanceling)
                return;

            isCanceling = true;
            StateHasChanged();

            var cancelRequestData = new CancelRequestCommandData(requestId);
            var cancelResult = await CancelRequestCommand.HandleAsync(cancelRequestData);
            if (!cancelResult.IsSuccess)
            {
                Snackbar.ShowResult(cancelResult, "Failed to cancel request. Please try again");
                isCanceling = false;
                StateHasChanged();
                return;
            }
 
            var selectedRow = Requests.FirstOrDefault(x => x.Id == requestId);
            if (selectedRow != null)
            {
                selectedRow.Status = StatusLookup.Cancelled.ToString();
                selectedRow.CloseDate ??= DateTime.Now;
            }

            isCanceling = false;
            StateHasChanged();
        }

        private async Task OpenRequestDetailDialogAsync(RequestSummaryDTO request)
        {
            var canEdit = isAdmin || CanCurrentUserAccessRequest(request);

            var parameters = new DialogParameters
            {
                ["RequestId"] = request.Id,
                ["IsRequestCertified"] = request.Status.Equals(StatusLookup.Closed.ToString(), StringComparison.OrdinalIgnoreCase) == true,
                ["CanEdit"] = canEdit

            };

            var options = new DialogOptions
            {
                MaxWidth = MaxWidth.Large,
                CloseOnEscapeKey = true,
                FullWidth = true
            };

            var dialog = await DialogService.ShowAsync<RequestDetailDialog>("Request Detail", parameters, options);

        }
        private async Task AddEditNoteAsync(int requestId, string adminNote)
        {
            var parameters = new DialogParameters
            {
                {"ExistingNote",  adminNote}
            };

            var options = new DialogOptions
            {
                MaxWidth = MaxWidth.Medium,
                CloseOnEscapeKey = true,
                FullWidth = true
            };

            var dialog = await DialogService.ShowAsync<AddEditNoteDialog>("Note", parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled)
            {
                string updateNote = result.Data?.ToString();

                var updateNoteData = new UpdateRequestNoteCommandData(requestId, updateNote);
                var noteResult = await UpdateRequestNoteCommand.HandleAsync(updateNoteData);
                if (!noteResult.IsSuccess)
                {
                    Snackbar.ShowResult(noteResult, "Failed to save note. Please try again.");
                    return;
                }

                var selectedRow = Requests.FirstOrDefault(x => x.Id == requestId);
                if (selectedRow != null)
                {
                    selectedRow.AdminNote = updateNote;
                }
                StateHasChanged();
                Snackbar.Add("Note Saved", Severity.Success);
            }
        }
        private string Truncate(string text, int len)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;
            return text.Length <= len ? text : text.Substring(0, len) + "...";
        }

        protected bool FilterFunc(RequestSummaryDTO request)
        {
            if (!string.IsNullOrWhiteSpace(searchString))
            {
                if (!(request.Id.ToString().Contains(searchString, StringComparison.OrdinalIgnoreCase) ||
                request.GroupName?.Contains(searchString, StringComparison.OrdinalIgnoreCase) == true ||
                request.FtbId?.Contains(searchString, StringComparison.OrdinalIgnoreCase) == true ||
                request.FullName?.Contains(searchString, StringComparison.OrdinalIgnoreCase) == true ||
                    request.TicketNumber?.Contains(searchString, StringComparison.OrdinalIgnoreCase) == true ||
                    request.DeviceNames?.Contains(searchString, StringComparison.OrdinalIgnoreCase) == true ||
                request.Status.Contains(searchString, StringComparison.OrdinalIgnoreCase) == true ||
                request.CloseDate.HasValue && request.CloseDate.Value.ToShortDateString().Contains(searchString, StringComparison.OrdinalIgnoreCase)))
                {
                    return false;
                }

            }

            if (!string.IsNullOrWhiteSpace(selectedStatus)
                && !string.Equals(request.Status, selectedStatus, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
            return true;

        }
    }
}
