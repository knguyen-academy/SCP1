﻿using Application.Services.CyberArk;

namespace BlazorServerUI.Features.Admin
{
    partial class Admin : ComponentBase
    {
        [Inject] NavigationManager NavigationManager { get; set; } = default!;
        [Inject] CyberArkService CyberArkService { get; set; } = default!;
        void ThrowException()
        {
            throw new Exception("TEST: Blazor UI Exception");
        }
        void ConfirmSuccess()
        {
            var message = "Successful Submitted";
            NavigationManager.NavigateTo($"{NavigationManager.BaseUri}confirmMessage?action={Uri.UnescapeDataString(message)}");
        }
        protected override void OnInitialized()
        {

        }
    }
}
