﻿using Application.DTOs.Request;
using Application.Features.Requests.Commands;
using Application.Services.Attachment;
using Application.Services.Auth;
using Application.Services.UserGroup;
using BlazorServerUI.Extensions;
using BlazorServerUI.Features.Common;
namespace BlazorServerUI.Features.Request
{
    public partial class NewRequest : ComponentBase
    {
        [Inject] CreateRequestCommand CreateRequestCommand { get; set; } = default;
        [Inject] IAuthService authService { get; set; } = default!;
        [Inject] IAttachmentService attachmentService { get; set; } = default!;
        [Inject] UserGroupService userGroupService { get; set; } = default!;
        [Inject] IDialogService DialogService { get; set; } = default!;
        [Inject] NavigationManager NavigationManager { get; set; } = default!;
        [Inject] AuthenticationStateProvider AuthenticationStateProvider { get; set; } = default!;
        [Inject] ISnackbar Snackbar { get; set; } = default!;
        List<ServerDTO> pendingServers { get; set; } = new();
        string? userNote;
        Guid tempRequestId = Guid.NewGuid();
        Guid submissionKey = Guid.NewGuid();
        string? groupDisplayName;
        Task<string>? groupDisplayNameTask;
        int attachmentCount = 0;
        bool isSubmitting = false;
        bool isOpeningAttachmentDialog = false;
        bool hasPendingServers => pendingServers.Count > 0;
        string submitStatus = "Processing";

        protected override void OnInitialized()
        {
            //prevent slow openning, load group once
            groupDisplayNameTask = LoadGroupDisplayNameAsync();
            _ = attachmentService.PreConfigSharepointApiAsync();
        }

        private async Task<string> LoadGroupDisplayNameAsync()
        {
            var ftbId = await authService.GetUserFtbId();
            var userGroup = await userGroupService.GetAppUserGroupByFtbUserIdAsync(ftbId);
            return userGroup.DisplayName;
        }

        private async Task OpenAttachmentDialog()
        {
            //prevent double click
            if (isOpeningAttachmentDialog)
                return;
            isOpeningAttachmentDialog = true;
            StateHasChanged();

            try
            {
                if (string.IsNullOrWhiteSpace(groupDisplayName))
                {
                    groupDisplayName = groupDisplayNameTask is not null ?
                                       await groupDisplayNameTask
                                       : await LoadGroupDisplayNameAsync();
                }


                var parameters = new DialogParameters
                {
                    ["RequestId"] = tempRequestId,
                    ["GroupDisplayName"] = groupDisplayName,
                    ["OnAttachmentUploaded"] = new Action<int>(UpdateAttachmentCount)
                };

                var options = new DialogOptions { CloseOnEscapeKey = true, MaxWidth = MaxWidth.Medium };
                await DialogService.ShowAsync<AttachmentDialog>("Attachments", parameters, options);
            }
            finally
            {
                isOpeningAttachmentDialog = false;
                StateHasChanged();
            }
          
        }
        void UpdateAttachmentCount(int count)
        {
            attachmentCount = count;
            StateHasChanged();
        }
        private async Task OpenCreateServerDialogAsync()
        {
  
            var options = new DialogOptions { CloseOnEscapeKey = true, MaxWidth = MaxWidth.Medium };
            var parameters = new DialogParameters { ["ExistingIps"] = pendingServers.Select(s => s.IpAddress ?? string.Empty).ToList() };
            var dialog = await DialogService.ShowAsync<CreateServerDialog>("Add Server",parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled && result.Data is ServerDTO newServer)
            {
                pendingServers.Add(newServer);
            }
        }

        private async Task OpenEditServerDialogAsync(ServerDTO editingServer)
        {
            var parameters = new DialogParameters
            {
                ["ExistingServer"] = editingServer,
                ["ExistingIps"] = pendingServers.Where(s=>s.ClientId != editingServer.ClientId).Select(s => s.IpAddress ?? string.Empty).ToList()
            };
            var options = new DialogOptions { CloseOnEscapeKey = true, MaxWidth = MaxWidth.Medium };
            var dialog = await DialogService.ShowAsync<EditServerDialog>("Edit Pending Server", parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled && result.Data is ServerDTO updatedServer)
            {
                var index = pendingServers.FindIndex(s => s.ClientId == editingServer.ClientId);
                if (index >= 0)
                    pendingServers[index] = updatedServer;
                StateHasChanged();
            }

        }

        private async Task OpenDuplicateServerDialogAsync(ServerDTO sourceServer)
        {
            var parameters = new DialogParameters
            {
                ["SourceServer"] = sourceServer,
                ["ExistingIps"] = pendingServers.Select(s => s.IpAddress ?? string.Empty).ToList()
            };
            var options = new DialogOptions { CloseOnEscapeKey = true, MaxWidth = MaxWidth.Medium };
            var dialog = await DialogService.ShowAsync<DuplicateServerDialog>("Duplicate Server", parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled && result.Data is ServerDTO duplicatedServer)
            {
                duplicatedServer.ServerId = null;
                duplicatedServer.ClientId = Guid.NewGuid();
                pendingServers.Add(duplicatedServer);
                StateHasChanged();
            }

        }
        void RemoveServer(ServerDTO deletedServer)
        {
            pendingServers.Remove(deletedServer);
        }

        private async Task Submit()
        {
            if (isSubmitting || !hasPendingServers)
                return;

            bool? dialogResult = await DialogService.ShowMessageBox(
                title: "Confirm",
                markupMessage: (MarkupString)"Are you sure you want to submit this request?<br />If you have any attachment(s), please upload before submitting.",
                yesText: "Yes, Submit",
                noText: "Cancel");

            if (dialogResult != true)
                return;

            isSubmitting = true;
            submitStatus = "Starting...";
            StateHasChanged();

            var requesterId = await authService.GetUserFtbId();
            var createRequestData = new CreateRequestCommandData(pendingServers, tempRequestId, submissionKey, requesterId, userNote);

            var process = new Progress<string>(status =>
            {
                submitStatus = status;
                InvokeAsync(StateHasChanged);
            });

            var createdResult = await CreateRequestCommand.HandleAsync(createRequestData, process);
            if (!createdResult.IsSuccess)
            {
                Snackbar.ShowResult(createdResult, "Failed to submit request. Please try again");
                isSubmitting = false;
                StateHasChanged() ;
                return;
            }
            
            isSubmitting = false;
            var message = "Successful Submitted";
            NavigationManager.NavigateTo($"{NavigationManager.BaseUri}confirmMessage?action={Uri.EscapeDataString(message)}");
        }
    }
}

