﻿using Application.Common.Lookups;
using Application.DTOs.Request;
using Application.Entities.SCR;
using Application.Features.Servers.Commands;
using Application.Features.Servers.Queries;
using BlazorServerUI.Extensions;

namespace BlazorServerUI.Features.Common
{

    public partial class RequestDetailDialog : ComponentBase
    {
        [Inject] IDialogService DialogService { get; set; } = default!;
        [CascadingParameter] IMudDialogInstance MudDialog { get; set; } = default!;
        [Inject] GetAllServersByRequestIdQuery GetAllServersByRequestIdQuery { get; set; } = default!;
        [Inject] UpdateServerCommand UpdateServerCommand { get; set; } = default!;
        [Inject] ISnackbar Snackbar { get; set; } = default!;
        [Parameter] public bool IsRequestCertified { get; set; }
        [Parameter] public int RequestId { get; set; }
        [Parameter] public bool CanEdit { get; set; }
        private List<Server>? Servers = new();
        private bool IsProcessing;

        protected override async Task OnInitializedAsync()
        {
            Servers = await GetAllServersByRequestIdQuery.HandleAsync(RequestId);
        }

        private async Task OpenEditServerDialogAsync(Server editingServer)
        {
            var editingServerDTO = MapToServerDto(editingServer);
            var parameters = new DialogParameters
            {
                ["ExistingServer"] = editingServerDTO,
                ["ExistingIps"] = Servers!.Where(s => s.Id != editingServer.Id)
                                           .Select(x => x.IpAddress ?? string.Empty).ToList(),
            };
            var options = new DialogOptions { CloseOnEscapeKey = true, MaxWidth = MaxWidth.Medium };
            var dialog = await DialogService.ShowAsync<EditServerDialog>("Edit Server", parameters, options);
            var result = await dialog.Result;

            if (!result.Canceled && result.Data is ServerDTO updatedServer)
            {
                IsProcessing = true;
                StateHasChanged();
                try
                {
                    var updatedResult = await UpdateServerCommand.HandleAsync(new UpdateServerCommandData(editingServer.Id, updatedServer));
                    if (updatedResult.IsSuccess)
                    {
                        Servers = await GetAllServersByRequestIdQuery.HandleAsync(RequestId);
                    }
                    else
                    {
                        Snackbar.ShowResult(updatedResult, "Failed to update server");
                    }
                }
                finally
                {
                    IsProcessing = false;
                    StateHasChanged();
                }
            }
        }

        public string ToYesNo(bool? value)
        {
            return value == true ? "Yes"
                   : value == false ? "No"
                   : "N/A";
        }
        public string GetDeviceTypeText(Server server)
        {
            var deviceText = server.Device?.Value ?? string.Empty;

            if (server.DeviceId == (int)DeviceLookup.DatabaseServer)
            {
                var databaseValue = server.Database?.Value;
                if (string.Equals(databaseValue, "Other", StringComparison.OrdinalIgnoreCase))
                {
                    return string.IsNullOrWhiteSpace(server.DatabaseOther)
                        ? deviceText
                        : $"{deviceText} - {server.DatabaseOther}";
                }
                if (!string.IsNullOrWhiteSpace(databaseValue))
                    return $"{deviceText} - {databaseValue}";
            }
            return deviceText;
        }

        public string GetOsTypeText(Server server)
        {
            var osText = server.Os?.Value ?? string.Empty;

            if (string.Equals(osText, "Other", StringComparison.OrdinalIgnoreCase))
            {
                return string.IsNullOrWhiteSpace(server.OsOther)
                    ? osText
                    : $"{server.OsOther}";
            }

            return osText;
        }
        void Cancel() => MudDialog?.Close(DialogResult.Cancel());
        private static ServerDTO MapToServerDto(Server server)
        {
            return new ServerDTO
            {
                ServerId = server.Id,
                Name = server.Name ?? string.Empty,
                IpAddress = server.IpAddress ?? string.Empty,
                OsVersion = server.OsVersion ?? string.Empty,
                CoreFunction = server.CoreFunction ?? string.Empty,
                Reason = server.Reason ?? string.Empty,
                Justification = server.Justification ?? string.Empty,
                OsOther = server.OsOther,
                DatabaseOther = server.DatabaseOther,
                PatchedDate = server.PatchedDate,
                ProductionPlanDate = server.ProductionPlanDate,
                IsOsPatched = server.IsOsPatched,
                IsCpradded = server.IsCpradded,
                IsImpervaAgentInstalled = server.IsImpervaAgentInstalled,
                IsTripwireAgentInstallled = server.IsTripwireAgentInstallled,
                IsDeviceLog = server.IsDeviceLog,
                IsCrowstrikeInstalled = server.IsCrowstrikeInstalled,
                IsBigFixAgentInstalled = server.IsBigFixAgentInstalled,
                IsSnowAtlasAgentInstalled = server.IsSnowAtlasAgentInstalled,
                IsSplunkForwarderInstalled = server.IsSplunkForwarderInstalled,
                IsFtiHandle = server.IsFtiHandle,
                OsId = server.OsId,
                EnvironmentId = server.EnvironmentId,
                DatabaseId = server.DatabaseId,
                DeviceId = server.DeviceId,
                CredentialId = server.CredentialId,
                ZoneId = server.ZoneId,
                HostId = server.HostId,
                LifecycleId = server.LifecycleId,
                ServerCustodian = server.ServerCustodian,
                BusinessOwner = server.BusinessOwner,
                ServerTeams = server.ServerTeam?.Select(e => e.Email).ToList() ?? new List<string>()
            };
        }
    }
}
