﻿using Application.DTOs.Dropdowns;
using Application.DTOs.Request;
using Application.Services.DropdownLookup;

namespace BlazorServerUI.Features.Common
{
    public partial class DuplicateServerDialog : ComponentBase
    {
        private ServerForm? _serverForm;
        private bool IsAllDropdownLoaded;
        private ServerDTO model { get; set; } = new();

        [Inject] IDropdownLookupService DropdownLookupService { get; set; } = default!;
        [CascadingParameter] IMudDialogInstance MudDialog { get; set; } = default!;

        [Parameter] public ServerDTO SourceServer { get; set; } = default!;
        [Parameter] public List<string> ExistingIps { get; set; } = new();

        protected override async Task OnParametersSetAsync()
        {
            await base.OnParametersSetAsync();
            IsAllDropdownLoaded = false;

            model = CloneServer(SourceServer);

            ResetForDuplicate(model);

            var dropdowns = await DropdownLookupService.GetAllDropdownDataAsync();
            model.EnvironmentList = dropdowns.Environments;
            model.ZoneList = dropdowns.Zones;
            model.OsList = dropdowns.Os;
            model.DeviceList = dropdowns.Devices;
            model.HostList = dropdowns.Hosts;
            model.LifecycleList = dropdowns.LifeCycles;
            model.CredentialList = dropdowns.Credentials;
            model.DatabaseList = dropdowns.Databases;

            IsAllDropdownLoaded = true;
            StateHasChanged();
        }

        private void Cancel() => MudDialog?.Close(DialogResult.Cancel());

        private async Task CreateCopy()
        {
            if (_serverForm is null)
                return;

            var isValid = await _serverForm.ValidateAsync();
            if (isValid)
            {
                MudDialog.Close(DialogResult.Ok(model));
            }
        }

        private static void ResetForDuplicate(ServerDTO dupServer)
        {
            dupServer.ServerId = null;

            dupServer.Name = string.Empty;
            dupServer.ZoneId = null;
            dupServer.IpAddress = string.Empty;
            dupServer.Reason = null;
            dupServer.Justification = null;

            dupServer.IsCrowstrikeInstalled = false;
            dupServer.IsBigFixAgentInstalled = false;
            dupServer.IsSnowAtlasAgentInstalled = false;
            dupServer.IsSplunkForwarderInstalled = false;
            dupServer.IsFtiHandle = null;

            dupServer.ServerTeams = new List<string>();
        }
        private static ServerDTO CloneServer(ServerDTO src)
        {
            var clone = new ServerDTO();
            foreach (var prop in typeof(ServerDTO).GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance))
            {
                if (!prop.CanRead || !prop.CanWrite)
                    continue;

                if (typeof(System.Collections.IEnumerable).IsAssignableFrom(prop.PropertyType)
                    && prop.PropertyType != typeof(string)
                    && prop.PropertyType != typeof(DropdownLookupDTO))
                    continue;
                prop.SetValue(clone, prop.GetValue(src));

            }

            clone.ServerTeams = src.ServerTeams?.ToList() ?? new List<string>();

            return clone;
        }
    }
}
