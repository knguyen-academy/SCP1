﻿namespace BlazorServerUI.Features.Common
{
    public partial class AddEditNoteDialog : ComponentBase
    {
        [Inject] IDialogService DialogService { get; set; } = default!;
        [CascadingParameter] IMudDialogInstance MudDialog { get; set; } = default!;
        [Parameter] public string ExistingNote { get; set; }
        private string NoteText { get; set; }
        protected override void OnInitialized()
        {
            if (!string.IsNullOrWhiteSpace(ExistingNote))
            {
                NoteText = ExistingNote.Trim();
            }
        }

        private void Save()
        {
            MudDialog.Close(DialogResult.Ok(NoteText));
        }
        void Cancel() => MudDialog?.Close(DialogResult.Cancel());
    }
}
