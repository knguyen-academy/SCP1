﻿using Application.Common.Lookups;
using Application.DTOs.Attachments;
using Application.Services.Attachment;
using Application.Settings;
using BlazorServerUI.Extensions;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.Extensions.Options;

namespace BlazorServerUI.Features.Common
{
    public partial class AttachmentDialog : ComponentBase
    {
        [Inject] IAttachmentService attachmentService { get; set; } = default!;
        [Inject] IDialogService DialogService { get; set; } = default!;
        [Inject] IOptions<UploadFileSetting> UploadSetting { get; set; } = default!;
        [CascadingParameter] IMudDialogInstance MudDialog { get; set; } = default!;
        [Parameter] public Guid RequestId { get; set; }
        [Parameter] public Action<int>? OnAttachmentUploaded { get; set; }
        [Parameter] public string GroupDisplayName { get; set; } = string.Empty;
        List<AttachmentModel> Attachments { get; set; } = new();
        bool IsUploading = false;
        bool CanUpload => Attachments.Any(a => a.Status == AttachmentStatus.Pending);
        int AttachmentCount = 0;
        bool Clearing = false;
        static string DefaultDragClass = "relative rounded-lg border-2 border-dashed pa-4 mt-4 mud-width-full mud-height-full";
        string DragClass = DefaultDragClass;
        [Inject] ISnackbar Snackbar { get; set; } = default!;

        UploadFileSetting _uploadSetting => UploadSetting.Value;
        private bool IsLoading;
        private Task? _prepareUploadFolderTask;

        protected override async Task OnInitializedAsync()
        {
            if (RequestId == Guid.Empty || string.IsNullOrWhiteSpace(GroupDisplayName))
                return;

            IsLoading = true;
            try
            {
                _prepareUploadFolderTask = attachmentService.PrepareUploadFolderAsync(GroupDisplayName, RequestId); //call api to prepare temp folder while browsing files, improve the upload speed
                await GetExistingUploadedFilesAsync();
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task GetExistingUploadedFilesAsync()
        {
            var result = await attachmentService.GetExistingFilesAsync(GroupDisplayName, RequestId);
            if (!result.IsSuccess)
            {
                Snackbar.ShowResult(result, "Failed to load existing attachments");
                Attachments = new List<AttachmentModel>();
                StateHasChanged();
                return;
            }
            Attachments = (result.Value ?? new List<AttachmentModel>()).Select(f => new AttachmentModel
            {
                //BrowserFile = null,
                Name = f.Name,
                Size = f.Size,
                FilePath = f.FilePath,
                Status = AttachmentStatus.Uploaded
            }).ToList();
            StateHasChanged();
        }

        private async Task OnInputFileChangedAsync(InputFileChangeEventArgs e)
        {
            ClearDragClass();
            foreach (var file in e.GetMultipleFiles())
            {

                if (file.Size > _uploadSetting.MaxFileSize)
                {
                    Snackbar.Add("File cannot exceed 20 MB", Severity.Warning);
                    continue;
                }
                if (Attachments.Any(f => 
                                    string.Equals(f.Name?.Trim(), file.Name?.Trim(), StringComparison.OrdinalIgnoreCase)
                                    && f.Size == file.Size))
                {
                    Snackbar.Add($"File {file.Name} already added", Severity.Warning);
                    continue;
                }
                if (!_uploadSetting.AllowedFileExtensions.Contains(Path.GetExtension(file.Name).ToLowerInvariant()))
                {
                    Snackbar.Add($"File {file.Name} is not allowed", Severity.Warning);
                    continue;
                }
                using var ms = new MemoryStream((int)file.Size);
                await file.OpenReadStream(_uploadSetting.MaxFileSize).CopyToAsync(ms);
                var content = ms.ToArray();
                Attachments.Add(new AttachmentModel
                {
                    //BrowserFile = file,
                    Content = content,
                    Name = file.Name,
                    Size = file.Size,
                    Status = AttachmentStatus.Pending
                });
            }
            StateHasChanged();
        }

        private async Task UploadAsync()
        {
            if (IsUploading)
                return;

            IsUploading = true;
            StateHasChanged();
            try
            {
                var pendingUploadFiles = Attachments.Where(f => f.Status == AttachmentStatus.Pending).ToList();
                if (!pendingUploadFiles.Any())
                    return;
                
                bool folderReady = false;
                if(_prepareUploadFolderTask is not null)
                {
                    try
                    {
                        await _prepareUploadFolderTask;
                        folderReady = true;
                    }
                    catch 
                    {
                        //service fall back to ensure folder 
                    }
                }


                var result = await attachmentService.UploadAsync(GroupDisplayName, RequestId, pendingUploadFiles);
                if (result.IsSuccess)
                {
                    foreach (var file in pendingUploadFiles)
                    {
                        file.Status = AttachmentStatus.Uploaded;
                    }
                    OnAttachmentUploaded?.Invoke(Attachments.Count(a => a.Status == AttachmentStatus.Uploaded));
                }
                else
                {
                    Snackbar.ShowResult(result, $"Failed to upload {result.Error?.Message}.");
                }
            }
            finally
            {
                IsUploading = false;
                StateHasChanged();
            }

        }
        private async Task RemoveAttachedFileAsync(AttachmentModel file)
        {
            if (file == null)
                return;

            //remove from memory
            if (file.Status == AttachmentStatus.Pending)
            {
                Attachments.Remove(file);
                OnAttachmentUploaded?.Invoke(Attachments.Count(a => a.Status == AttachmentStatus.Uploaded));
                Snackbar.Add($"{file.Name} deleted.", Severity.Info);
                StateHasChanged();
                return;
            }

            var result = await attachmentService.DeleteAsync(GroupDisplayName, RequestId, file.Name);
            if (!result.IsSuccess)
            {
                Snackbar.ShowResult(result, $"Failed to delete {file.Name}.");
                StateHasChanged();
                return;
            }
            Attachments.Remove(file);
            OnAttachmentUploaded?.Invoke(Attachments.Count(a => a.Status == AttachmentStatus.Uploaded));
            Snackbar.Add($"{file.Name} deleted.", Severity.Info);
            StateHasChanged();
        }
        Color GetChipColor(AttachmentStatus status)
            => status == AttachmentStatus.Uploaded ? Color.Success : Color.Default;
        string GetChipIcon(AttachmentStatus status)
            => status == AttachmentStatus.Uploaded ? Icons.Material.Filled.Check : Icons.Material.Filled.Description;
        void Close() => MudDialog.Close(DialogResult.Ok(true));
        private void SetDragClass()
        {
            DragClass = $"{DefaultDragClass} mud-border-primary";
        }
        private void ClearDragClass()
        {
            DragClass = DefaultDragClass;
        }
    }
}
