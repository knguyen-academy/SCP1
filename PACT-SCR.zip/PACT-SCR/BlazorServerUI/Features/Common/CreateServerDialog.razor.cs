﻿using Application.DTOs.Request;
using Application.Services.DropdownLookup;

namespace BlazorServerUI.Features.Common
{
    public partial class CreateServerDialog : ComponentBase
    {
        private ServerForm? _serverForm;
        private ServerDTO model { get; set; } = new();

        [Inject] IDropdownLookupService DropdownLookupService { get; set; } = default!;
        [Inject] IHostEnvironment HostEnvironment { get; set; } = default!;
        [CascadingParameter] IMudDialogInstance MudDialog { get; set; } = default!;

        [Parameter] public int RequestId { get; set; } = default!;
        [Parameter] public List<string> ExistingIps { get; set; } = new();
        private bool ShowTestDataButton => !HostEnvironment.IsProduction();

        protected override async Task OnInitializedAsync()
        {
            await base.OnInitializedAsync();

            var dropdowns = await DropdownLookupService.GetAllDropdownDataAsync();

            model.EnvironmentList = dropdowns.Environments;
            model.ZoneList = dropdowns.Zones;
            model.OsList = dropdowns.Os;
            model.DeviceList = dropdowns.Devices;
            model.HostList = dropdowns.Hosts;
            model.LifecycleList = dropdowns.LifeCycles;
            model.CredentialList = dropdowns.Credentials;
            model.DatabaseList = dropdowns.Databases;
        }

        private async Task AddServer()
        {
            if (_serverForm is null)
                return;
            
            var isValid = await _serverForm.ValidateAsync();
            if (isValid) 
            {
                MudDialog.Close(DialogResult.Ok(model));
            }
        }

        private void ApplyTestData()
        {
            model.IsOsPatched = true;
            model.ProductionPlanDate = DateTime.Today;
            model.Name = "Test Host Name";
            model.EnvironmentId = model.EnvironmentList.FirstOrDefault().Id;
            model.CoreFunction = "Test CoreFunction";
            model.OsId = model.OsList.FirstOrDefault().Id;
            model.OsVersion = "Test Version";
            model.DeviceId = model.DeviceList.FirstOrDefault().Id;
            model.HostId = model.HostList.FirstOrDefault().Id;
            model.LifecycleId = model.LifecycleList.FirstOrDefault().Id;
            model.IsCpradded = true;
            model.IsDeviceLog = true;
            model.CredentialId = model.CredentialList.FirstOrDefault().Id;
            model.IsBigFixAgentInstalled = true;

        }
        private void Cancel() => MudDialog?.Close(DialogResult.Cancel());
      
    }
}
