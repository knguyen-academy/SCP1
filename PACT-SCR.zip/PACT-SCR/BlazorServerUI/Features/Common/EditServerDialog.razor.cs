﻿using Application.DTOs.Dropdowns;
using Application.DTOs.Request;
using Application.Services.DropdownLookup;

namespace BlazorServerUI.Features.Common
{
    public partial class EditServerDialog : ComponentBase
    {
        private ServerForm? _serverForm;
        private bool IsAllDropdownLoaded;
        private ServerDTO model { get; set; } = new();

        [Inject] IDropdownLookupService DropdownLookupService { get; set; } = default!;
        [CascadingParameter] IMudDialogInstance MudDialog { get; set; } = default!;

        [Parameter] public ServerDTO ExistingServer { get; set; } = default!;
        [Parameter] public List<string> ExistingIps { get; set; } = new();
        protected override async Task OnParametersSetAsync()
        {
            await base.OnParametersSetAsync();

            model = CloneServer(ExistingServer);

            IsAllDropdownLoaded = false;

            var dropdowns = await DropdownLookupService.GetAllDropdownDataAsync();
            model.EnvironmentList = dropdowns.Environments;
            model.ZoneList = dropdowns.Zones;
            model.OsList = dropdowns.Os;
            model.DeviceList = dropdowns.Devices;
            model.HostList = dropdowns.Hosts;
            model.LifecycleList = dropdowns.LifeCycles;
            model.CredentialList = dropdowns.Credentials;
            model.DatabaseList = dropdowns.Databases;

            IsAllDropdownLoaded = true;
            StateHasChanged();
        }


        void Cancel() => MudDialog?.Close(DialogResult.Cancel());

        async Task SaveServer()
        {
            if (_serverForm is null)
                return;

            var isValid = await _serverForm.ValidateAsync();
            if (isValid)
            {
                MudDialog.Close(DialogResult.Ok(model));
            }
        }

        private static ServerDTO CloneServer(ServerDTO src)
        {
            var clone = new ServerDTO();
            foreach (var prop in typeof(ServerDTO).GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance))
            {
                if (!prop.CanRead || !prop.CanWrite)
                    continue;

                if (typeof(System.Collections.IEnumerable).IsAssignableFrom(prop.PropertyType)
                    && prop.PropertyType != typeof(string)
                    && prop.PropertyType != typeof(DropdownLookupDTO))
                    continue;
                prop.SetValue(clone, prop.GetValue(src));
            }
            clone.ServerTeams = src.ServerTeams?.ToList() ?? new List<string>();
            return clone;
        }
    }
}
