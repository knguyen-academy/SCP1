﻿using Application.Common.Errors;
using Application.Common.Lookups;
using Application.Common.Validations;
using Application.DTOs.Request;
using Application.Services.FtbEmployee;
using Application.Services.Servers;
using FluentValidation;

namespace BlazorServerUI.Features.Common
{
    public partial class ServerForm : ComponentBase
    {
        [Parameter] public ServerDTO Model { get; set; } = default!;
        [Parameter] public List<string> ExistingIps { get; set; } = new();

        [Parameter] public bool IsPendingEdit { get; set; } = default;
        [Parameter] public int? EditingServerId { get; set; } = default;
        [Inject] public ServerService ServerService { get; set; } = default!;
        [Inject] public FtbEmployeeService FtbEmployeeService { get; set; } = default!;
        [Inject] public IDialogService DialogService { get; set; } = default!;
        public MudForm Form { get; set; } = default!;
        private ServerDTOValidator modelValidator = default!;

        private bool OverrideBusy;
        private bool IpInUseByActiveServer;
        private bool IsDuplicateInRequest;
        private string? IpInUseByActiveServerValue;
        private MudTextField<string>? _ipField;
        private MudAutocomplete<string> _autoComplete;
        private const int MaxRecordsToFetch = 20;

        protected override void OnParametersSet()
        {
            modelValidator = new ServerDTOValidator(ValidateIpMessageAsync);
        }

        public async Task<bool> ValidateAsync()
        {
            await Form.Validate();
            return Form.IsValid;
        }

        private bool IsDatabaseOrFileOrSharepointDeviceTypeSelected()
        {
            var selectedValueId = Model.DeviceId;
            if (selectedValueId is null)
                return false;

            return selectedValueId == (int)DeviceLookup.DatabaseServer
            || selectedValueId == (int)DeviceLookup.FileServer;
            //|| selectedValueId == (int)DeviceLookup.SharepointServer;
        }
        private async Task<IEnumerable<string>> SearchFTBEmail(string value, CancellationToken token)
        {
            var maxRecordToFetch = MaxRecordsToFetch;
            var ftbEmails = new List<string>();
            if (!string.IsNullOrEmpty(value))
            {
                ftbEmails = await FtbEmployeeService.GetFtbEmailsBySearchKeyAsync(value,maxRecordToFetch);
            }

            return ftbEmails;
        }
        private async Task ServerTeamSearchChanged(string email)
        {
            if (string.IsNullOrEmpty(email))
                return;

            if(Model.ServerTeams.Contains(email, StringComparer.OrdinalIgnoreCase))
            {
                await _autoComplete.ClearAsync();
                return;
            }

            Model.ServerTeams.Add(email);
            await _autoComplete.ClearAsync();
        }
        private void RemoveServerTeamEmail(MudChip<string> chip) => Model.ServerTeams.Remove(chip.Value);
        private string? ValidateServerTeams(string? _) => Model.ServerTeams.Count == 0 ? "At least one Application team is required." : null;
        public bool IsDatabaseServerDeviceSelected()
        {
            var selectedValueId = Model.DeviceId;
            if (selectedValueId is null)
                return false;
            return selectedValueId == (int)DeviceLookup.DatabaseServer;

        }
        private bool IsZoneIpException()
        {
            if (Model.ZoneId is null)
                return false;
            return Model.ZoneId == (int)ZoneIpLookup.Exception;
        }
        private bool IsDatabaseOtherSelected()
        {
            var selectedDatabase = Model.SelectedDatabase;
            if (selectedDatabase is null)
                return false;

            return selectedDatabase.Value == "Other";
        }

        private bool IsOsOtherSelected()
        {
            var selectedOs = Model.SelectedOS;
            if (selectedOs is null)
                return false;

            return selectedOs.Value == "Other";
        }

        private void OnOsPatchChanged(bool? value)
        {
            Model.IsOsPatched = value;
            if (value != false)
            {
                Model.PatchedDate = null;
            }
        }
        private void OnOsSelectChanged(int? osId)
        {
            Model.OsId = osId;
            if (!IsOsOtherSelected())
            {
                Model.OsOther = null;
            }
        }
        private void OnZoneIPChanged(int? zoneId)
        {
            Model.ZoneId = zoneId;

            var selectedZone = Model.SelectedZone;
            string selectedZoneValue = selectedZone?.Value ?? string.Empty;

            Model.IpAddress = ExtractIpPrefix(selectedZoneValue);

            if (!IsZoneIpException())
            {
                Model.Reason = null;
                Model.Justification = null;
            }
        }
        void OnDatabaseTypeChanged(int? databaseId)
        {
            Model.DatabaseId = databaseId;
            if (!IsDatabaseOtherSelected())
            {
                Model.DatabaseOther = null;
            }
        }
        void OnDeviceSelectChanged(int? deviceId)
        {
            Model.DeviceId = deviceId;

            if (!IsDatabaseOrFileOrSharepointDeviceTypeSelected())
            {
                Model.IsImpervaAgentInstalled = null;
            }

            if (!IsDatabaseServerDeviceSelected())
            {
                Model.DatabaseId = null;
                Model.DatabaseOther = null;
            }

        }

        private async Task CheckIpStatusAsync()
        {
            IsDuplicateInRequest = false;
            IpInUseByActiveServer = false;
            IpInUseByActiveServerValue = null;

            var currentIp = Model.IpAddress?.Trim();

            var (isDuplicate, isInUse, _) = await ValidateIpAsync(Model.IpAddress);
            IsDuplicateInRequest = isDuplicate;

            if (isInUse)
            {
                IpInUseByActiveServer = true;
                IpInUseByActiveServerValue = currentIp;
            }
        }

        private async Task OverrideIpAsync()
        {
            if (OverrideBusy)
                return;
            if (!IpInUseByActiveServer)
            {
                await CheckIpStatusAsync();
                if (!IpInUseByActiveServer)
                    return;
            }
            bool? dialogResult = await DialogService.ShowMessageBox(
               title: "Confirm",
               markupMessage: (MarkupString)"Are you sure you want to override this Ip Address?",
               yesText: "Yes, Override",
               noText: "Cancel");

            if (dialogResult != true)
                return;

            var ip = Model.IpAddress?.Trim();
            if (string.IsNullOrEmpty(ip))
                return;
            OverrideBusy = true;
            StateHasChanged();

            try
            {
                await ServerService.DeactivateActiveServersByIpAsync(ip);
                IpInUseByActiveServer = false;
                IsDuplicateInRequest = false;
                IpInUseByActiveServerValue = null;

                _ipField?.ResetValidation();
                await CheckIpStatusAsync();


                StateHasChanged();
            }
            finally
            {
                OverrideBusy = false;
                StateHasChanged();
            }

        }

        private static string ExtractIpPrefix(string inputIpWithLabel)
        {
            int colonIndex = inputIpWithLabel.IndexOf(":");
            string ipFromDropdown = (colonIndex >= 0) ? inputIpWithLabel.Substring(colonIndex + 1).Trim() : inputIpWithLabel.Trim();

            if (ipFromDropdown.Contains("or", StringComparison.OrdinalIgnoreCase)) return string.Empty;

            //Split octets
            var parts = ipFromDropdown.Split(".");
            if (parts.Length < 2)
                return string.Empty;

            var prefixBuilder = new System.Text.StringBuilder();
            foreach (var part in parts)
            {
                string p = part.Trim();
                if (p.Equals("xxx", StringComparison.OrdinalIgnoreCase) || p.Contains("-") || p.Contains(","))
                    break;
                if (prefixBuilder.Length > 0)
                    prefixBuilder.Append(".");
                prefixBuilder.Append(p);

            }

            if (prefixBuilder.Length > 0)
                prefixBuilder.Append('.');
            return prefixBuilder.ToString();

        }

        private async Task<(bool IsDuplicateInRequest, bool IsInUseByActiveServer, string? Message)> ValidateIpAsync(string? ip)
        {
            if (string.IsNullOrWhiteSpace(ip))
                return (false, false, null);

            ip = ip.Trim();

            if (ExistingIps.Any(x => string.Equals(x?.Trim(), ip, StringComparison.OrdinalIgnoreCase)))
                return (true, false, AppErrors.IpDuplicateInRequest(ip).Message);

            //Dup in DB
            var existedIp = await ServerService.GetActiveIpInUseAsync(ip, IsPendingEdit ? EditingServerId: null);
            if (existedIp is not null)
                return (false, true, AppErrors.IpActiveInUse(existedIp).Message);

            return (false, false, null);
        }

        private async Task<string?> ValidateIpMessageAsync(string? ip)
        {
            var (_, _, message) = await ValidateIpAsync(ip);
            return message;
        }

        public sealed class ServerDTOValidator : AbstractValidator<ServerDTO>
        {
            private readonly Func<string?, Task<string?>> _validateIp;
            public ServerDTOValidator(Func<string?, Task<string?>> validateIp)
            {
                _validateIp = validateIp;
            }
            public Func<object, string, Task<IEnumerable<string>>> ValidateValue => async (obj, propertyName) =>
            {
                var dto = (ServerDTO)obj;
                var issues = ServerDtoRules.ValidateProperty(dto, propertyName);
                if (issues.Count > 0)
                    return issues.Select(i => i.Message);

                if (propertyName == nameof(ServerDTO.IpAddress))
                {
                    var message = await _validateIp(dto.IpAddress);
                    if (message is not null)
                        return new[] { message };
                }
                return Array.Empty<string>();
            };
        }
    }
}
