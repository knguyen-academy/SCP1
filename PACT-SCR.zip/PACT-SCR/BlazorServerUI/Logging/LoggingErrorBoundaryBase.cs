﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace BlazorServerUI.Logging
{
    public class LoggingErrorBoundaryBase : ErrorBoundaryBase
    {
        [Inject] protected ILogger<LoggingErrorBoundaryBase> Logger { get; set; } = default;
        [Inject] NavigationManager NavigationManager { get; set; } = default!;
        protected override Task OnErrorAsync(Exception exception)
        {
            //Logger.LogError(exception, "Unhandled Blazor UI exception");
            Logger.LogError(exception, exception.Message);
            return Task.CompletedTask;
        }

        public void Reload() => NavigationManager.NavigateTo(NavigationManager.BaseUri, forceLoad: true);
 
    }
}
