﻿using Application.Common.Errors;
using Application.Common.Results;

namespace BlazorServerUI.Extensions
{
    public static class SnackbarResultExtensions
    {
        public static void ShowResult(this ISnackbar snackbar, Result result, string fallbackMessage)
        {
            if(result.IsSuccess) return;
            var message = result.Error?.Message ?? fallbackMessage;
            var severity = MapSeverity(result.Error?.Code);
            snackbar.Add(message, severity);
        }
        private static Severity MapSeverity(string? code)
        {
            if (code.StartsWith("ATTACHMENT_", StringComparison.OrdinalIgnoreCase))
                return Severity.Warning;

            return Severity.Error;
        }
    }
}
