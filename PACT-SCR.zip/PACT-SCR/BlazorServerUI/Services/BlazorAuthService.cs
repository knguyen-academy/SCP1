﻿using Application.Services.Auth;

namespace BlazorServerUI.Services
{
    public class BlazorAuthService : IAuthService
    {
        private readonly AuthenticationStateProvider _authProvider;
        public BlazorAuthService(AuthenticationStateProvider authProvider)
        {
            _authProvider = authProvider;
        }

        public async Task<string> GetUserFtbId()
        {
            AuthenticationState authState = null;
            try
            {
                authState = await _authProvider.GetAuthenticationStateAsync();
            }
            catch (InvalidOperationException ex)
            {
                return "Place holder UserId";
            }
            var authUser = authState?.User;
            var userId = authUser?.Identity.Name;
            if (userId is null)
            {
                throw new UnauthorizedAccessException("Cannot retrieve user's Id.");
            }
            userId = userId.Replace("FTB\\", "");
            return userId;
        }

        public async Task<bool> IsInRole(string roleName)
        {
            var authState = await _authProvider.GetAuthenticationStateAsync();
            var authUser = authState.User;
            var userId = authUser.Identity?.Name;
            if (userId is null)
            {
                throw new UnauthorizedAccessException("Cannot retrieve user's Id.");
            }
            return authUser.IsInRole(roleName);
        }

    }
}
