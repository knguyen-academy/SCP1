﻿using Application.Security.Interface;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace BlazorServerUI.Auth
{
    public class CustomClaimTransformation : IClaimsTransformation
    {
        private readonly ISecurityService _securityService;
        public CustomClaimTransformation(ISecurityService securityService)
        {
            _securityService = securityService;
        }

        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var appUsers = await _securityService.GetAllUsersWithRoleQueryAsync();
            ClaimsIdentity claimsIdentity = new ClaimsIdentity();
            foreach (var user in appUsers)
            {
                if (principal.IsInRole(user.FtbId))
                {
                    var claimRoleExist = claimsIdentity.HasClaim(x => x.Type == ClaimTypes.Role && x.Value == user.Role.Value);
                    var claimWindowsAccountNameExist = claimsIdentity.HasClaim(x => x.Type == ClaimTypes.WindowsAccountName && x.Value == user.FtbId);
                    if (!claimRoleExist)
                    {
                        claimsIdentity.AddClaim(new Claim(ClaimTypes.Role, user.Role.Value));

                    }
                    if (!claimWindowsAccountNameExist)
                    {
                        claimsIdentity.AddClaim(new Claim(ClaimTypes.WindowsAccountName, user.FtbId));
                    }
                }
            }
            principal.AddIdentity(claimsIdentity);
            return principal;
        }
    }
}
