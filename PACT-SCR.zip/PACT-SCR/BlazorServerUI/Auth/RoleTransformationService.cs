﻿
using Application.Security.Interface;
using Application.Services.Auth;

namespace BlazorServerUI.Auth
{
    public class RoleTransformationService : IRoleTransformationService
    {
        private readonly IPlatformUserService _platformUserService;
        private readonly ISecurityService _securityService;
        public RoleTransformationService(IPlatformUserService platformUserService, ISecurityService securityService)
        {
            _platformUserService = platformUserService;
            _securityService = securityService;
        }

        public async Task<List<string>> TransformRolesAsync()
        {
            var appUsers = await _securityService.GetAllUsersWithRoleQueryAsync();
            var platformUserGroups = _platformUserService.GetUserGroups();
            List<string> transformedRoles = new List<string>();
            foreach (var user in appUsers)
            {
                if (platformUserGroups.Contains(user.FtbId))
                {
                    if (!transformedRoles.Contains(user.Role.Value))
                    {
                        transformedRoles.Add(user.Role.Value);
                    }
                }
            }
            return transformedRoles;
        }
    }
}
