﻿namespace BlazorServerUI.Auth
{
    public interface IRoleTransformationService
    {
        Task<List<string>> TransformRolesAsync();
    }
}
