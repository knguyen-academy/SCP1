﻿
using Application.Services.Auth;
using System.Security.Principal;

namespace BlazorServerUI.Auth
{
    public class WindowPlatformUserService : IPlatformUserService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public WindowPlatformUserService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Interoperability", "CA1416:Validate platform compatibility", Justification = "<Pending>")]
        public List<string> GetUserGroups()
        {
            var userGroups = new List<string>();
            var user = _httpContextAccessor?.HttpContext?.User.Identity;
            if (user is null)
            {
                return userGroups;
            }

            var windowsUser = user as WindowsIdentity;
            var windowsUserGroups = windowsUser?.Groups;
            if (windowsUserGroups != null)
            {
                foreach(var group in windowsUserGroups)
                {
                    userGroups.Add(group.Translate(typeof(NTAccount)).ToString());
                }
            }
            return userGroups;
                
        }
    }
}
