﻿namespace BlazorServerUI.Auth
{
    public static class AppPolicy
    {
        public const string CanCreateRequest = "CanCreateRequest"; //not using, all users can create requests now
    }
}
