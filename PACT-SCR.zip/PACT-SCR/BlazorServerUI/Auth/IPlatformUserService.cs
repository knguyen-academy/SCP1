﻿namespace BlazorServerUI.Auth
{
    public interface IPlatformUserService
    {
        List<string> GetUserGroups();
    }
}
