﻿namespace BlazorServerUI.Auth
{
    public static class AppRoleName
    {
        public const string SystemAdmin = "SA";
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
