﻿using Application.DTOs;
using Application.Entities.SCR;
using Application.Persistence.SCR;
using Microsoft.EntityFrameworkCore;


namespace Application.Features.Servers.Queries
{
    //public record GetServerByIdQueryData(int Id);
    public class GetServerByIdQuery
    {
        private readonly SCRContext _db;
        public GetServerByIdQuery(SCRContext db)
        {
            _db = db;
        }

        public async Task<Server?> HandleAsync(int id)
        {
            return await _db.Server.Include(x=>x.ServerTeam).FirstOrDefaultAsync(s=>s.Id == id);
        }
    }
}
