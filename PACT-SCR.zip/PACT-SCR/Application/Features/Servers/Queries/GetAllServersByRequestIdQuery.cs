﻿using Application.Entities.SCR;
using Application.Persistence.SCR;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Servers.Queries
{
    public class GetAllServersByRequestIdQuery
    {
        private readonly SCRContext _db;
        public GetAllServersByRequestIdQuery(SCRContext db)
        {
            _db = db;
        }

        public async Task<List<Server>> HandleAsync(int RequestId)
        {
            var result =  await _db.Server
                            .AsNoTracking()
                            .Where(x=>x.RequestId == RequestId)
                            .Include(x=>x.Lifecycle)
                            .Include(x=> x.Credential)
                            .Include(x=> x.Database)
                            .Include(x=> x.Device)
                            .Include(x=> x.Host)
                            .Include(x=> x.Environment)
                            .Include(x=> x.Os)
                            .Include(x=> x.Zone)
                            .Include(x=> x.ServerTeam)
                            .ToListAsync();
            return result;
        }
    }
}
