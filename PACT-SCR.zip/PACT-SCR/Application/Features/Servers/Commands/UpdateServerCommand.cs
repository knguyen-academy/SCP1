﻿using Application.Common.Errors;
using Application.Common.Results;
using Application.DTOs.Request;
using Application.Entities.SCR;
using Application.Persistence.FTBEmployee;
using Application.Persistence.SCR;
using Application.Services.Attachment;
using Application.Services.Servers;
using FluentValidation;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Servers.Commands
{
    public record UpdateServerCommandData(int ServerId, ServerDTO UpdatedServer);
    public class UpdateServerCommand
    {
        private readonly SCRContext _scrContext;
        private readonly FTBEmployeeContext _fTBEmployeeContext;
        private readonly IValidator<ServerDTO> _validator;
        private readonly ServerService _serverService;
        private readonly IAttachmentService _attachmentService;

        public UpdateServerCommand(SCRContext scrContext, FTBEmployeeContext fTBEmployeeContext,  IValidator<ServerDTO> validator, ServerService serverService, IAttachmentService attachmentService)
        {
            _scrContext = scrContext;
            _fTBEmployeeContext = fTBEmployeeContext;
            _validator = validator;
            _serverService = serverService;
            _attachmentService = attachmentService;
        }
        public async Task<Result> HandleAsync(UpdateServerCommandData data)
        {
            var serverToUpdate = await _scrContext.Server
                                          .Include(s => s.ServerTeam)
                                          .FirstOrDefaultAsync(s => s.Id == data.ServerId);
            if (serverToUpdate is null)
                return Result.Failure(AppErrors.ServerNotFound(data.ServerId));

            var validation = await _validator.ValidateAsync(data.UpdatedServer);
            if (!validation.IsValid)
            {
                var message = string.Join("\n", validation.Errors.Select(e => e.ErrorMessage));
                return Result.Failure(AppErrors.ValidationFailed(message));
            }

            var ip = data.UpdatedServer.IpAddress?.Trim();

            //Check duplicate Ip within the request
            var duplicateIpInSameRequest = await _scrContext.Server.AnyAsync(s => s.RequestId == serverToUpdate.RequestId
                                                              && s.Id != serverToUpdate.Id
                                                              && s.IpAddress == ip);

            if (duplicateIpInSameRequest)
                return Result.Failure(AppErrors.IpDuplicateInRequest(ip));

            //Check duplicate Ip in DB
            var activeServer = await _serverService.GetActiveIpInUseAsync(ip, serverToUpdate.Id);
            if (activeServer is not null)
                return Result.Failure(AppErrors.IpActiveInUse(ip));

            _scrContext.ServerTeam.RemoveRange(serverToUpdate.ServerTeam);

            UpdateServer(serverToUpdate, data.UpdatedServer);
            await _scrContext.SaveChangesAsync();
            return await RegrantPermissionFolderForNewContactsAsync(serverToUpdate.RequestId);
        }

        private async Task<Result> RegrantPermissionFolderForNewContactsAsync(int requestId)
        {
            var request = await _scrContext.CertificationRequest
                                   .Include(r => r.Group)
                                   .Include(r => r.Server).ThenInclude(s => s.ServerTeam)
                                   .FirstOrDefaultAsync(r => r.Id == requestId);

            if (request is null
                || string.IsNullOrWhiteSpace(request.TicketNumber)
                || request.Group is null
                || string.IsNullOrWhiteSpace(request.Group.DisplayName))
            {
                return Result.Success();
            }

            var requesterEmail = await _fTBEmployeeContext.EHremployeeDaily
                                                          .Where(x => x.NetworkId == request.FtbId)
                                                          .Select(x => x.Email)
                                                          .FirstOrDefaultAsync();
            var emails = request.Server
                                .SelectMany(s => s.ServerTeam ?? new List<ServerTeam>())
                                .Select(e => e.Email)
                                .Append(requesterEmail)
                                .Where(e => !string.IsNullOrWhiteSpace(e))
                                .Distinct(StringComparer.OrdinalIgnoreCase)
                                .ToList();

            return await _attachmentService.RegrantRequestFolderForNewContactsAsync(request.Group.DisplayName, request.TicketNumber, emails);
        }

        private void UpdateServer(Server serverToUpdate, ServerDTO updatedServer)
        {
            serverToUpdate.Name = updatedServer.Name;
            serverToUpdate.IpAddress = updatedServer.IpAddress?.Trim() ?? string.Empty;
            serverToUpdate.OsId = updatedServer.OsId;
            serverToUpdate.OsVersion = updatedServer.OsVersion;
            serverToUpdate.EnvironmentId = updatedServer.EnvironmentId;
            serverToUpdate.DatabaseId = updatedServer.DatabaseId;
            serverToUpdate.DeviceId = updatedServer.DeviceId;
            serverToUpdate.CredentialId = updatedServer.CredentialId;
            serverToUpdate.ZoneId = updatedServer.ZoneId;
            serverToUpdate.IsOsPatched = updatedServer.IsOsPatched;
            serverToUpdate.HostId = updatedServer.HostId;
            serverToUpdate.LifecycleId = updatedServer.LifecycleId;
            serverToUpdate.CoreFunction = updatedServer.CoreFunction;
            serverToUpdate.IsCpradded = updatedServer.IsCpradded;
            serverToUpdate.IsImpervaAgentInstalled = updatedServer.IsImpervaAgentInstalled;
            serverToUpdate.PatchedDate = updatedServer.PatchedDate;
            serverToUpdate.IsTripwireAgentInstallled = updatedServer.IsTripwireAgentInstallled;
            serverToUpdate.IsDeviceLog = updatedServer.IsDeviceLog;
            serverToUpdate.Reason = updatedServer.Reason;
            serverToUpdate.Justification = updatedServer.Justification;
            serverToUpdate.IsCrowstrikeInstalled = updatedServer.IsCrowstrikeInstalled;
            serverToUpdate.IsBigFixAgentInstalled = updatedServer.IsBigFixAgentInstalled;
            serverToUpdate.IsSnowAtlasAgentInstalled = updatedServer.IsSnowAtlasAgentInstalled;
            serverToUpdate.IsSplunkForwarderInstalled = updatedServer.IsSplunkForwarderInstalled;
            serverToUpdate.IsFtiHandle = updatedServer.IsFtiHandle;
            serverToUpdate.OsOther = updatedServer.OsOther;
            serverToUpdate.ProductionPlanDate = updatedServer.ProductionPlanDate;
            serverToUpdate.DatabaseOther = updatedServer.DatabaseOther;
            serverToUpdate.ServerCustodian = updatedServer.ServerCustodian;
            serverToUpdate.BusinessOwner = updatedServer.BusinessOwner;

            foreach (var email in (updatedServer.ServerTeams ?? new List<string>())
                                    .Where(e => !string.IsNullOrWhiteSpace(e))
                                    .Select(e => e.Trim()
                                    .ToLowerInvariant())
                                    .Distinct())
            {
                serverToUpdate.ServerTeam.Add(new ServerTeam {ServerId = serverToUpdate.Id, Email = email });
            }
        }
    }
}
