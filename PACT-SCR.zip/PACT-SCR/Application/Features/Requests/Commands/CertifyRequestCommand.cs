﻿using Application.Common.Errors;
using Application.Common.Lookups;
using Application.Common.Results;
using Application.Entities.SCR;
using Application.Persistence.FTBEmployee;
using Application.Persistence.SCR;
using Application.Services.Attachment;
using Application.Services.Email;
using Application.Services.FreshServices;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Requests.Commands
{
    public record CertifyRequestCommandData(int RequestId);

    /// <summary>
    /// Certify steps:
    /// 1- Load request
    /// 2- Move files to Certified folder (also preserves permissions)
    /// 3- Close FreshService ticket
    /// 4- Send certify notification email
    /// 5- Mark request and servers as closed 
    /// </summary>
    public class CertifyRequestCommand
    {
        readonly IAttachmentService _attachmentService;
        readonly IFreshService _freshService;
        readonly SOCEmailService _socEmailService;
        readonly SCRContext _db;
        readonly FTBEmployeeContext _fTBEmployeeContext;

        public CertifyRequestCommand(SCRContext dbContext, FTBEmployeeContext fTBEmployeeContext, IAttachmentService attachmentService, IFreshService freshService, SOCEmailService socEmailService)
        {
            _db = dbContext;
            _fTBEmployeeContext = fTBEmployeeContext;
            _attachmentService = attachmentService;
            _freshService = freshService;
            _socEmailService = socEmailService;
        }

        public async Task<Result<int>> HandleAsync(CertifyRequestCommandData data)
        {
            var request = await LoadRequestAsync(data.RequestId);
            if (request is null)
                return Result<int>.Failure(AppErrors.RequestNotFound(data.RequestId));

            if (request.StatusId == (int)StatusLookup.Closed)
                return Result<int>.Success(request.Id);

            if (string.IsNullOrWhiteSpace(request.TicketNumber))
                return Result<int>.Failure(AppErrors.TicketNotFound(data.RequestId));

            var groupDisplayName = request.Group?.DisplayName;

            var moveResult = await MoveToSharePointCertifiedAsync(groupDisplayName, request.TicketNumber);
            if (!moveResult.IsSuccess)
                return Result<int>.Failure(moveResult.Error!.Code, moveResult.Error.Message);

            // After move success, FS close task, send email task, and DB task can run concurrently.
            var fsCloseTask = _freshService.CloseFSTicketAsync(request.TicketNumber);
            var emailTask = SendCertifyNotificationEmailAsync(request.Id, request.FtbId, request.Server);
            var dbCloseTask = CloseRequestAsync(request);
            await Task.WhenAll(fsCloseTask, emailTask, dbCloseTask);

            return Result<int>.Success(request.Id);
        }

        private async Task SendCertifyNotificationEmailAsync(int requestId, string ftbId, ICollection<Server> servers)
        {
            var requesterEmail = await _fTBEmployeeContext.EHremployeeDaily
                                                            .Where(x => x.NetworkId == ftbId)
                                                            .Select(x => x.Email)
                                                            .FirstOrDefaultAsync() ?? string.Empty;
            var serverContacts = servers
                                .SelectMany(s => s.ServerTeam ?? new List<ServerTeam>())
                                .Select(e => e.Email)
                                .Where(e => !string.IsNullOrWhiteSpace(e))
                                .Distinct(StringComparer.OrdinalIgnoreCase)
                                .ToList();

            await _socEmailService.SendCertifyEmailAsync(requestId, requesterEmail, serverContacts);
        }

        private async Task<CertificationRequest?> LoadRequestAsync(int requestId)
        {
            return await _db.CertificationRequest
                .Include(x => x.Server)
                .ThenInclude(s => s.ServerTeam)
                .Include(r => r.Group)
                .FirstOrDefaultAsync(x => x.Id == requestId);
        }

        private async Task<Result> MoveToSharePointCertifiedAsync(string groupDisplayName, string fsTicketId)
        {
            var result = await _attachmentService.MoveForCloseAsync(groupDisplayName, fsTicketId);
            if (!result.IsSuccess)
                return Result.Failure(result.Error?.Code ?? AppErrors.MoveFailed().Code, result.Error?.Message ?? AppErrors.MoveFailed().Message);

            return Result.Success();
        }

        private async Task CloseRequestAsync(CertificationRequest request)
        {
            request.StatusId = (int)StatusLookup.Closed;
            request.CloseDate ??= DateTime.UtcNow;

            foreach (var server in request.Server)
            {
                server.IsActive = false;
            }

            _db.CertificationRequest.Update(request);
            await _db.SaveChangesAsync();
        }
    }
}