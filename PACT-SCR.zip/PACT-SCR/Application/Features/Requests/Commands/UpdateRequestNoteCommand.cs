﻿using Application.Common.Errors;
using Application.Common.Results;
using Application.Persistence.SCR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Requests.Commands
{
    public record UpdateRequestNoteCommandData(int RequestId, string Note);
    public class UpdateRequestNoteCommand
    {
        private const int MaxNoteLength = 1000;
        private readonly SCRContext _db;
        public UpdateRequestNoteCommand(SCRContext db)
        {
            _db = db;
        }
        public async Task<Result<int>> HandleAsync(UpdateRequestNoteCommandData data)
        {
            if (data is null)
                return Result<int>.Failure(AppErrors.ValidationFailed("Request data is missing"));

            var note = data.Note ?? string.Empty;
            if (note.Length > MaxNoteLength)
                return Result<int>.Failure(AppErrors.ValidationFailed($"Note cannot exceed {MaxNoteLength} characters."));

            var request = await _db.CertificationRequest.FirstOrDefaultAsync(r => r.Id == data.RequestId);
            if (request is null)
                return Result<int>.Failure(AppErrors.RequestNotFound(data.RequestId));

            request.AdminNote = data.Note;
            await _db.SaveChangesAsync();

            return Result<int>.Success(request.Id);
        }
    }
}
