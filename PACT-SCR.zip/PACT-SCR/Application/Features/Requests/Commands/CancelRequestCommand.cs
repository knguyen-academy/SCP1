﻿using Application.Common.Errors;
using Application.Common.Lookups;
using Application.Common.Results;
using Application.Entities.SCR;
using Application.Persistence.SCR;
using Application.Services.Attachment;
using Application.Services.FreshServices;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Requests.Commands
{
    public record CancelRequestCommandData(int RequestId);

    /// <summary>
    /// Cancel request flow:
    /// 1- Load request 
    /// 2- Move all files to Archive folder
    /// 3- Revoke all SharePoint folder permissions
    /// 4- Close FreshService ticket
    /// 5- Mark request and servers as cancelled
    /// </summary>
    public class CancelRequestCommand
    {
        readonly IAttachmentService _attachmentService;
        readonly IFreshService _freshService;
        readonly SCRContext _db;

        public CancelRequestCommand(SCRContext dbContext, IAttachmentService attachmentService, IFreshService freshService)
        {
            _db = dbContext;
            _attachmentService = attachmentService;
            _freshService = freshService;
        }

        public async Task<Result<int>> HandleAsync(CancelRequestCommandData data)
        {
            var request = await LoadRequestAsync(data.RequestId);

            if (request is null)
                return Result<int>.Failure(AppErrors.RequestNotFound(data.RequestId));

            if (request.StatusId == (int)StatusLookup.Cancelled)
                return Result<int>.Success(request.Id);

            if (string.IsNullOrWhiteSpace(request.TicketNumber))
                return Result<int>.Failure(AppErrors.TicketNotFound(data.RequestId));

            var groupDisplayName = request.Group?.DisplayName;

            var moveResult = await MoveToSharePointArchiveAsync(groupDisplayName, request.TicketNumber);
            if (!moveResult.IsSuccess)
                return Result<int>.Failure(moveResult.Error!.Code, moveResult.Error.Message);

            var revokeResult = await RevokeAccessAsync(groupDisplayName, request.TicketNumber);
            if (!revokeResult.IsSuccess)
                return Result<int>.Failure(revokeResult.Error!.Code, revokeResult.Error.Message);

            await _freshService.CloseFSTicketAsync(request.TicketNumber);

            await CancelRequestAsync(request);

            return Result<int>.Success(request.Id);
        }

        
        private async Task<CertificationRequest?> LoadRequestAsync(int requestId)
        {
            return await _db.CertificationRequest
                .Include(x => x.Server)
                .Include(x => x.Group)
                .FirstOrDefaultAsync(x => x.Id == requestId);
        }

        private async Task<Result> MoveToSharePointArchiveAsync(string? groupDisplayName, string fsTicketId)
        {
            var result = await _attachmentService.MoveForCancelAsync(groupDisplayName, fsTicketId);
            if (!result.IsSuccess)
                return Result.Failure(result.Error?.Code ?? AppErrors.MoveFailed().Code, result.Error?.Message ?? AppErrors.MoveFailed().Message);

            return Result.Success();
        }

        private async Task<Result> RevokeAccessAsync(string? groupDisplayName, string fsTicketId)
        {
            var result = await _attachmentService.RevokeArchivedFolderAccessAsync(groupDisplayName, fsTicketId);
            if (!result.IsSuccess)
                return Result.Failure(result.Error?.Code ?? AppErrors.MoveFailed().Code, result.Error?.Message ?? AppErrors.MoveFailed().Message);

            return Result.Success();
        }

        private async Task CancelRequestAsync(CertificationRequest request)
        {
            request.StatusId = (int)StatusLookup.Cancelled;
            request.CloseDate ??= DateTime.UtcNow;

            foreach (var server in request.Server)
            {
                server.IsActive = false;
            }

            _db.CertificationRequest.Update(request);
            await _db.SaveChangesAsync();
        }
    }
}