﻿using Application.DTOs.Request;
using FluentValidation;

namespace Application.Features.Requests.Commands
{
    public class CreateRequestCommandDataValidator: AbstractValidator<CreateRequestCommandData>
    {
        public CreateRequestCommandDataValidator(IValidator<ServerDTO> serverValidator)
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.FtbId).NotEmpty().WithMessage("FTBId is required.");
            RuleFor(x => x.TempRequestId).NotEqual(Guid.Empty).WithMessage("TempRequestId is required.");
            RuleFor(x => x.SubmissionKey).NotEqual(Guid.Empty).WithMessage("SubmissionKey is required.");
            RuleFor(x => x.UserNote).MaximumLength(1000).WithMessage("Note cannot exceed 1000 characters.");
            RuleFor(x => x.Servers).NotNull().WithMessage("Servers is required.").Must(s=>s is { Count: >0}).WithMessage("At least one server is required.");
            RuleForEach(x=>x.Servers)
                .SetValidator(serverValidator);
        }
    }
}
