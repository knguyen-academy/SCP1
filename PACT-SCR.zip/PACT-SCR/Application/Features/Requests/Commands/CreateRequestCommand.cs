﻿using Application.Common.Errors;
using Application.Common.Lookups;
using Application.Common.Results;
using Application.DTOs.Request;
using Application.DTOs.Requests;
using Application.Entities.SCR;
using Application.Persistence.FTBEmployee;
using Application.Persistence.SCR;
using Application.Services.Attachment;
using Application.Services.Email;
using Application.Services.FreshServices;
using Application.Services.Servers;
using Application.Services.UserGroup;
using FluentValidation;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Requests.Commands
{
    public record CreateRequestCommandData(List<ServerDTO> Servers, Guid TempRequestId, Guid SubmissionKey, string FtbId, string? UserNote);

    /// <summary>
    /// Create request steps:
    /// 1- Validate input (FluentValidation + duplicate/active IP checks)
    /// 2- Create Request with empty FS number, 'pending' status in case other steps fail
    /// 3- Create FS Ticket if not yet created
    /// 4- Set up SharePoint folder: ensure folder, move attachments, create Old Reports folder, copy master file, grant access
    /// 5- Activate request and servers in DB
    /// 6- Send confirmation and ISOU emails
    /// </summary>
    public class CreateRequestCommand
    {
        private readonly IAttachmentService _attachmentService;
        private readonly IFreshService _freshService;
        private readonly SCRContext _db;
        private readonly UserGroupService _userGroupService;
        private readonly ServerService _serverService;
        private readonly IValidator<CreateRequestCommandData> _validator;
        private readonly SOCEmailService _socEmailService;
        private readonly FTBEmployeeContext _fTBEmployeeContext;

        public CreateRequestCommand(SCRContext dbContext,
            IAttachmentService attachmentService,
            IFreshService freshService,
            UserGroupService userGroupService,
            ServerService serverService,
            IValidator<CreateRequestCommandData> validator,
            FTBEmployeeContext fTBEmployeeContext,
            SOCEmailService socEmailService)
        {
            _db = dbContext;
            _attachmentService = attachmentService;
            _freshService = freshService;
            _userGroupService = userGroupService;
            _serverService = serverService;
            _validator = validator;
            _socEmailService = socEmailService;
            _fTBEmployeeContext = fTBEmployeeContext;
        }

        public async Task<Result<int>> HandleAsync(CreateRequestCommandData data, IProgress<string>? progress = null)
        {
            // Step 1: Validate input (FluentValidation + duplicate/active IP checks)
            var validationResult = await ValidateRequestAsync(data);
            if (validationResult is not null)
                return validationResult;

            // Step 2: Returns existing pending request or creates a new one
            progress?.Report("Creating request...");
            var userGroup = await _userGroupService.GetAppUserGroupByFtbUserIdAsync(data.FtbId);
            var existedRequest = await GetOrCreateRequestAsync(data, userGroup);
            if (existedRequest.StatusId != (int)StatusLookup.Pending)
                return Result<int>.Success(existedRequest.Id);

            // Step 3: Create FreshService ticket if not already created 
            progress?.Report("Creating FreshService ticket...");
            await EnsureTicketNumberAsync(data, existedRequest, userGroup);

            // Step 4: SharePoint operations : folder setup, file move from temp to ticketNumber, copy master file, grant access folder 
            progress?.Report("Setting up SharePoint...");
            var sharePointResult = await SetupSharePointAsync(data, existedRequest, userGroup, progress);
            if (!sharePointResult.IsSuccess)
                return Result<int>.Failure(sharePointResult.Error!.Code, sharePointResult.Error.Message);

            // Step 5: Mark request as Open and activate all its servers
            var servers = await MarkRequestActiveAsync(existedRequest);

            // Step 6: Send confirmation email to requester (CC: server emails) + ISOU email for exception-zone servers
            progress?.Report("Sending confirmation emails...");
            await SendNotificationsEmailAsync(data, existedRequest, servers, userGroup);

            return Result<int>.Success(existedRequest.Id);
        }


        private async Task<Result<int>?> ValidateRequestAsync(CreateRequestCommandData data)
        {
            var validation = await _validator.ValidateAsync(data);
            if (!validation.IsValid)
            {
                var message = string.Join("; ",
                    validation.Errors
                              .Where(e => e is not null)
                              .Select(e => string.IsNullOrWhiteSpace(e.PropertyName) ? e.ErrorMessage : $"{e.PropertyName}: {e.ErrorMessage}")
                              .Distinct(StringComparer.Ordinal));
                return Result<int>.Failure(AppErrors.ValidationFailed(message));
            }

            var duplicateIpInTheSameRequest = data.Servers
                                                    .Select(s => s.IpAddress?.Trim())
                                                    .Where(ip => !string.IsNullOrWhiteSpace(ip))
                                                    .GroupBy(ip => ip!, StringComparer.OrdinalIgnoreCase)
                                                    .Where(g => g.Count() > 1)
                                                    .Select(g => g.Key)
                                                    .ToList();

            if (duplicateIpInTheSameRequest.Count > 0)
                return Result<int>.Failure(AppErrors.IpDuplicateInRequest(duplicateIpInTheSameRequest.First()));

            var ipsToCheck = data.Servers
                                .Select(s => s.IpAddress?.Trim())
                                .Where(ip => !string.IsNullOrEmpty(ip))
                                .Distinct(StringComparer.OrdinalIgnoreCase)
                                .ToList();

            var activeServers = await _serverService.GetActiveIpInUseAsync(ipsToCheck);
            var foundActiveServer = activeServers.Values.FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));
            if (foundActiveServer is not null)
                return Result<int>.Failure(AppErrors.IpActiveInUse(foundActiveServer));

            return null;
        }

        private async Task<CertificationRequest> GetOrCreateRequestAsync(CreateRequestCommandData data, UserGroupDTO userGroup)
        {
            var existedRequest = await _db.CertificationRequest.FirstOrDefaultAsync(x => x.SubmissionKey == data.SubmissionKey);
            if (existedRequest is null)
            {
                var requestId = await AddInitialAsync(data.Servers, data.FtbId, userGroup, data.SubmissionKey, data.UserNote);
                existedRequest = await _db.CertificationRequest.FindAsync(requestId);
            }
            return existedRequest!;
        }

        private async Task EnsureTicketNumberAsync(CreateRequestCommandData data, CertificationRequest request, UserGroupDTO userGroup)
        {
            if (!string.IsNullOrWhiteSpace(request.TicketNumber))
                return;

            long fsTicketId = await _freshService.CreateTicketAsync(data.FtbId, data.Servers, userGroup, data.UserNote);
            request.TicketNumber = fsTicketId.ToString();
            await _db.SaveChangesAsync();
        }

        private async Task<Result> SetupSharePointAsync(CreateRequestCommandData data, CertificationRequest request, UserGroupDTO userGroup, IProgress<string>? progress = null)
        {
            // Ticket folder must exist before the other tasks
            progress?.Report("Setting Sharepoint folder...");
            var ensured = await _attachmentService.EnsureTicketFolderAsync(userGroup.DisplayName, request.TicketNumber);
            if (!ensured.IsSuccess)
                return ensured;
            
            var requesterEmail = await _fTBEmployeeContext.EHremployeeDaily
                                                          .Where(x => x.NetworkId == data.FtbId)
                                                          .Select(x => x.Email)
                                                          .FirstOrDefaultAsync();

            progress?.Report("Granting Sharepoint folder access...");
            var grantEmails = data.Servers
                .SelectMany(s => s.ServerTeams ?? new List<string>())
                .Append(requesterEmail)
                .Where(e => !string.IsNullOrWhiteSpace(e))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            progress?.Report("Wrapping up Sharepoint task...");
            // These four tasks are independent of each other so run them in parallel
            var moveTask = _attachmentService.MoveForCreateAsync(userGroup.DisplayName, data.TempRequestId, request.TicketNumber);

            var oldReportTask = _attachmentService.CreateOldReportFolderAsync(userGroup.DisplayName, request.TicketNumber);

            var masterCopyTask = _attachmentService.CopyMasterFileAsync(userGroup.DisplayName, request.TicketNumber, request.RequestDate);

            var grantTask = grantEmails.Count > 0
                ? _attachmentService.GrantRequestFolderAccessAsync(userGroup.DisplayName, request.TicketNumber, grantEmails)
                : Task.FromResult(Result.Success());

            var results = await Task.WhenAll(moveTask, oldReportTask, masterCopyTask, grantTask);
            var firstFailure = results.FirstOrDefault(r => !r.IsSuccess);
            return firstFailure ?? Result.Success();
        }

        private async Task<List<Server>> MarkRequestActiveAsync(CertificationRequest request)
        {
            request.StatusId = (int)StatusLookup.Open;

            var servers = await _db.Server.Where(s => s.RequestId == request.Id).ToListAsync();
            foreach (var server in servers)
            {
                server.IsActive = true;
            }

            await _db.SaveChangesAsync();
            return servers;
        }
        private async Task SendNotificationsEmailAsync(CreateRequestCommandData data, CertificationRequest request, List<Server> servers, UserGroupDTO userGroup)
        {
            var requester = await _fTBEmployeeContext.EHremployeeDaily.FirstOrDefaultAsync(x => x.NetworkId == data.FtbId);
            if (requester is null)
                return;

            var serverTeamsCc = data.Servers
                .SelectMany(s => s.ServerTeams ?? new List<string>())
                .Where(e => !string.IsNullOrWhiteSpace(e))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            var ccEmails = new List<string> { requester.Email };
            ccEmails.AddRange(serverTeamsCc);

            var confirmEmailTask = _socEmailService.SendConfirmEmailAsync(
                                                    request.Id,
                                                    request.TicketNumber,
                                                    userGroup.DisplayName,
                                                    data.Servers,
                                                    data.UserNote,
                                                    new List<string> { requester.Email },
                                                    ccEmails);

            var exceptionZoneServers = servers.Where(x => x.ZoneId == (int)ZoneIpLookup.Exception).ToList();
            var isouEmailTask = exceptionZoneServers.Count > 0
                ? _socEmailService.SendISOUEmailAsync(
                    $"{requester.LastName}, {requester.FirstName} ({requester.NetworkId})",
                    request.Id,
                    exceptionZoneServers)
                : Task.CompletedTask;

            await Task.WhenAll(confirmEmailTask, isouEmailTask);
        }

        private async Task<int> AddInitialAsync(List<ServerDTO> servers, string ftbId, UserGroupDTO userGroup, Guid submissionKey, string? userNote)
        {
            var newRequest = new CertificationRequest
            {
                RequestDate = DateTime.UtcNow,
                SubmissionKey = submissionKey,
                FtbId = ftbId,
                StatusId = (int)StatusLookup.Pending,
                GroupId = userGroup.Id,
                TicketNumber = string.Empty,
                UserNote = string.IsNullOrWhiteSpace(userNote) ? null : userNote
            };

            var newServers = servers.Select(addServer => new Server
            {
                Name = addServer.Name,
                IpAddress = addServer.IpAddress,
                OsId = addServer.OsId,
                OsVersion = addServer.OsVersion,
                EnvironmentId = addServer.EnvironmentId,
                DatabaseId = addServer.DatabaseId,
                DeviceId = addServer.DeviceId,
                CredentialId = addServer.CredentialId,
                ZoneId = addServer.ZoneId,
                IsOsPatched = addServer.IsOsPatched,
                HostId = addServer.HostId,
                LifecycleId = addServer.LifecycleId,
                CoreFunction = addServer.CoreFunction,
                IsCpradded = addServer.IsCpradded,
                IsImpervaAgentInstalled = addServer.IsImpervaAgentInstalled,
                PatchedDate = addServer.PatchedDate,
                IsTripwireAgentInstallled = addServer.IsTripwireAgentInstallled,
                IsDeviceLog = addServer.IsDeviceLog,
                Reason = addServer.Reason,
                Justification = addServer.Justification,
                IsCrowstrikeInstalled = addServer.IsCrowstrikeInstalled,
                IsBigFixAgentInstalled = addServer.IsBigFixAgentInstalled,
                IsSnowAtlasAgentInstalled = addServer.IsSnowAtlasAgentInstalled,
                IsSplunkForwarderInstalled = addServer.IsSplunkForwarderInstalled,
                IsFtiHandle = addServer.IsFtiHandle,
                OsOther = addServer.OsOther,
                ProductionPlanDate = addServer.ProductionPlanDate,
                DatabaseOther = addServer.DatabaseOther,
                ServerCustodian = addServer.ServerCustodian,
                BusinessOwner = addServer.BusinessOwner,
                ServerTeam = (addServer.ServerTeams ?? new List<string>())
                              .Where(e => !string.IsNullOrWhiteSpace(e))
                              .Select(e => new ServerTeam { Email = e.Trim().ToLowerInvariant() })
                              .ToList(),
                IsActive = false
            }).ToList();

            if (newServers.Count > 0)
                newRequest.Server = newServers;

            await _db.CertificationRequest.AddAsync(newRequest);
            await _db.SaveChangesAsync();
            return newRequest.Id;
        }
    }
}