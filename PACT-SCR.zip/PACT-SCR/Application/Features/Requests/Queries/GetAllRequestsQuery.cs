﻿using Application.Common.Lookups;
using Application.DTOs.Request;
using Application.Entities.SCR;
using Application.Persistence.FTBEmployee;
using Application.Persistence.SCR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Features.Requests.Queries
{
    public class GetAllRequestsQuery
    {
        private readonly SCRContext _scrContext;
        private readonly FTBEmployeeContext _ftbEmployeeContext;
        public GetAllRequestsQuery(SCRContext scrContext, FTBEmployeeContext ftbEmployeeContext)
        {
            _scrContext = scrContext;
            _ftbEmployeeContext = ftbEmployeeContext;
        }

        public async Task<List<RequestSummaryDTO>> HandleAsync()
        {
            var requests = await _scrContext.CertificationRequest
                .Where(x => x.StatusId != (int)StatusLookup.Pending)
                .Select(x => new RequestSummaryDTO
                {
                    Id = x.Id,
                    GroupName = x.Group.DisplayName,
                    FtbId = x.FtbId,
                    TicketNumber = x.TicketNumber,
                    DeviceNames = string.Empty,
                    RequestDate = x.RequestDate,
                    CloseDate = x.CloseDate,
                    Status = x.Status.Value,
                    AdminNote = x.AdminNote

                }).ToListAsync();

            if (requests.Count == 0)
                return requests;

            var requestIds = requests.Select(x => x.Id).ToList();
            var serverNames = await _scrContext.Server.AsNoTracking()
                                                        .Where(s => requestIds.Contains(s.RequestId))
                                                        .OrderBy(s => s.Name)
                                                        .Select(s => new { s.RequestId, s.Name })
                                                        .ToListAsync();

            var namesByRequestId = serverNames.GroupBy(x => x.RequestId).ToDictionary(g => g.Key, g => string.Join(", ", g.Select(x => x.Name)));

            var serverTeams = await _scrContext.ServerTeam.AsNoTracking()
                                                                .Where(c => requestIds.Contains(c.Server.RequestId))
                                                                .Select(c => new { c.Server.RequestId, c.Email })
                                                                .ToListAsync();
            var contactsByRequestId = serverTeams.GroupBy(x => x.RequestId).ToDictionary(g => g.Key, g => g.Select(x => x.Email).Where(e => !string.IsNullOrWhiteSpace(e)).Distinct(StringComparer.OrdinalIgnoreCase).ToList());

            foreach (var request in requests)
            {
                if (namesByRequestId.TryGetValue(request.Id, out var names))
                    request.DeviceNames = names;

                if (contactsByRequestId.TryGetValue(request.Id, out var contacts))
                    request.ServerTeams = contacts;
            }
            var userIds = requests.Select(x => x.FtbId).Distinct().ToList();
            var employees = await _ftbEmployeeContext.EHremployeeDaily
                                                    .AsNoTracking()
                                                    .Where(x => userIds.Contains(x.NetworkId))
                                                    .ToDictionaryAsync(x => x.NetworkId, StringComparer.OrdinalIgnoreCase);

            foreach (var request in requests)
            {
                if (employees.TryGetValue(request.FtbId, out var emp))
                {
                    request.RequesterFirstName = emp.FirstName;
                    request.RequesterLastName = emp.LastName;
                }
            }
            return requests;
        }
    }
}
