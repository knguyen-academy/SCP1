﻿using Application.Entities.SCR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Security.Interface
{
    public interface ISecurityService
    {
        Task<List<AppUserRole>> GetAllUsersWithRoleQueryAsync();
    }
}
