﻿using Application.Entities.SCR;
using Application.Persistence.SCR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Security.Interface
{
    public class SecurityService : ISecurityService
    {
        private readonly SCRContext _context;
        public SecurityService(SCRContext context)
        {
            _context = context;
        }

        public async Task<List<AppUserRole>> GetAllUsersWithRoleQueryAsync()
        {
            var usersWithRole = await _context.AppUserRole
                                              .Include(x => x.Role)
                                              .ToListAsync();
            return usersWithRole;
        }
    }
}
