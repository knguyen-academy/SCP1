﻿using Application.DTOs.Sharepoint;
using Application.Settings;
using Microsoft.Extensions.Options;
using PACT.CyberArk.Api.Contracts;
using PACT.CyberArk.ApiClient;
namespace Application.Services.CyberArk
{
    public class CyberArkService
    {
        private readonly IOptionsSnapshot<CyberArkSetting> _cyberArkOption;
        private readonly IOptionsSnapshot<SharePointSetting> _spOption;
        private readonly PactCyberArkApiClient _cyberArkClient;
        public CyberArkService(IOptionsSnapshot<CyberArkSetting> cyberArkOption, PactCyberArkApiClient cyberArkClient, IOptionsSnapshot<SharePointSetting> spOption)
        {
            _cyberArkOption = cyberArkOption;
            _cyberArkClient = cyberArkClient;
            _spOption = spOption;
        }

        public async Task<SharepointCredential> GetSharePointApiCredentialsAsync()
        {
            var sharpointClientSecretFromCyberArkResponse = await GetCredentialFromCyberArkAsync(
                                                    _cyberArkOption.Value.ApplicationId, 
                                                    _cyberArkOption.Value.CredentialId);
            return new SharepointCredential
            {
                TenantId = _spOption.Value.TenantId,
                ClientId = _spOption.Value.ClientId,
                ClientSecret = sharpointClientSecretFromCyberArkResponse!.Password
            };
        }

        public async Task<CredentialResponse?> GetCredentialFromCyberArkAsync(int appId, Guid credentialId)
        {
            var request = new CredentialRequest(appId, credentialId, "SCP app.");

            var result = await _cyberArkClient.GetCredential(request)
                          ?? throw new Exception("Couldn't get credential response.");
            return result;
        }

    }
}
