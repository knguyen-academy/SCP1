﻿using Application.DTOs.Request;
using Application.DTOs.Requests;
using Application.Settings;
using Microsoft.Extensions.Options;
using Package.FreshService;
using Package.FreshService.Models.Tickets;
using Package.ReadonlyThirdParty;
using System.Net;
using System.Text;

namespace Application.Services.FreshServices
{
    public class FreshService : IFreshService
    {
        private readonly FreshServiceContext _fsContext;
        private readonly ReadonlyThirdPartyContext _fsRoContext;
        private readonly IOptionsSnapshot<SharePointSetting> _sharePointConfig;
        private readonly IOptionsSnapshot<AppSetting> _appConfig;
        public FreshService(FreshServiceContext fsContext,
                            ReadonlyThirdPartyContext fsRoContext,
                            IOptionsSnapshot<SharePointSetting> sharePointConfig,
                            IOptionsSnapshot<AppSetting> appConfig)
        {
            _fsContext = fsContext;
            _fsRoContext = fsRoContext;
            _sharePointConfig = sharePointConfig;
            _appConfig = appConfig;
        }

        private SharePointSetting _sharepointSettings => _sharePointConfig.Value;
        private AppSetting _appSettings => _appConfig.Value;

        public async Task<long> CreateTicketAsync(string requesterId, List<ServerDTO> servers, UserGroupDTO userGroup, string? userNote)
        {
            var assingedGroup = await _fsRoContext.Groups.FindByNameAsync("SOC");
            var ftbUser = await _fsRoContext.Users.FindByFtbIdAsync(requesterId);
            var ftbUserEmail = ftbUser.Data.PrimaryEmail;
            string ticketSubject = "Security Certification Request";
            string ticketDescription = GetTicketDescription(servers, userGroup, userNote);
            var ticket = new TicketWrite()
            {
                Subject = ticketSubject,
                DescriptionHtml = $"<div>{ticketDescription}</div>",
                RequesterEmail = ftbUserEmail,
                Priority = 1, //This value comes from the FreshService.TicketPriority table
                Status = 2, //This value comes from the FreshService.TicketStatus table
                Category = "Software",  //This value comes from the FreshService.TicketCategory table
                WorkspaceId = 2, //must be 2
                Type = "Service Request",  //"Incident" / "Major Incident" / "Service Request"
                Source = 1, //This value comes from the FreshService.Source table
                ResolutionNotes = "<div><b></b></div>", //can use html for this field, but the created ticket will remove html elements from this field
                                                        //ResolutionNotesHtml will include everything
                Impact = 1, //This value comes from the FreshService.Impact table
                RequesterId = ftbUser.Data.Id, //This value comes from the FreshService.User table
                GroupId = assingedGroup.Data.Id,  //This value comes from the FreshService.Group table
            };
            var response = await _fsContext.Tickets.CreateAsync(ticket);
            if (response.IsSuccess)
            {
                var ticketID = response.Data.Ticket.Id;
                await UpdateTicketDescriptionFSAsync(ticketDescription, "ticketNumberPlaceHolder", ticketID);
                return ticketID;
            }
            else
            {
                throw new Exception("Failed to create ticket.");
            }
        }

        public async Task<List<string>> GetFsGroupsByFsUserIdAsync(long freshServiceUserId)
        {
            var userGroupList = new List<string>();
            var query = $"$filter=UserId eq {freshServiceUserId} &$expand=User,Group";
            var userGroupResult = await _fsRoContext.UserGroups.QueryAsync(query);
            var userGroups = userGroupResult.Data.Value;
            foreach (var userGroup in userGroups)
            {
                userGroupList.Add(userGroup.Group.Name);
            }
            return userGroupList;
        }

        public async Task<long?> GetFsUserIdAsync(string requesterId)
        {
            var ftbUser = await _fsRoContext.Users.FindByFtbIdAsync(requesterId);
            return ftbUser.Data.Id;
        }

        public async Task<long> CloseFSTicketAsync(string ticketId)
        {
            TicketWrite ticketToUpdate = new TicketWrite()
            {
                Status = 5,
            };
            var updateResponse = await _fsContext.Tickets.UpdateAsync(Convert.ToInt64(ticketId), ticketToUpdate);
            if (updateResponse.IsSuccess)
            {
                return updateResponse.Data.Ticket.Id;
            }
            else
            {
                throw new Exception(updateResponse.ErrorMessage);
            }
        }
        private async Task UpdateTicketDescriptionFSAsync(string inputString, string replaceString, long ticketId)
        {
            string ticketDescription = string.Empty;
            ticketDescription = inputString.Replace($"{replaceString}", $"{ticketId.ToString()}");

            TicketWrite ticketToUpdate = new TicketWrite()
            {
                DescriptionHtml = ticketDescription,

            };
            var updateResponse = await _fsContext.Tickets.UpdateAsync(ticketId, ticketToUpdate);
            if (updateResponse.IsSuccess)
            {
                return;
            }
            else
            {
                throw new Exception(updateResponse.ErrorMessage);
            }
        }
        private string GetTicketDescription(List<ServerDTO> servers, UserGroupDTO userGroup, string? userNote)
        {
            string tempTicketNumber = "ticketNumberPlaceHolder";
            var noteDisplay = string.IsNullOrWhiteSpace(userNote) ? "N/A" : userNote;
            var ticketUrl = BuildFreshServiceTicketUrl(tempTicketNumber);
            var sharePointFolderUrl = BuildSharePointFolderUrl(userGroup.DisplayName, tempTicketNumber);

            StringBuilder description = new StringBuilder();
            description.AppendLine("<div style='font-family: Arial, sans-serif; font-size: 14px; color: #111; line-height: 1.45;'>");
            description.AppendLine("<p>Hello,</p>");
            description.AppendLine("<p>A new security certification request has been created. Your participation may be required. Please follow the link below to view the service request.</p>");

            description.AppendLine("<p>");
            description.AppendLine($"Security Certification Request: {BuildLink(ticketUrl, tempTicketNumber)}<br />");
            description.AppendLine($"Security Findings Sheet: {BuildLink(sharePointFolderUrl, "SharePoint folder")}<br />");
            description.AppendLine("</p>");

            description.AppendLine("<p><b>Servers:</b></p>");
            description.AppendLine(BuildServerSection(servers));

            description.AppendLine($"<p>Note: {Html(noteDisplay)}</p>");

            description.AppendLine("<p><b>Expectations:</b></p>");
            description.AppendLine("<ul>");
            description.AppendLine("<li>Server certification request should be completed within 5 business days. If there is no progress in remediating security findings after 5 business days, Security may request to shut down the systems.</li>");
            description.AppendLine("<li>Systems should not be in production until they have been certified.</li>");
            description.AppendLine("</ul>");

            description.AppendLine("<p><b>Procedures and FAQ's:</b></p>");
            description.AppendLine("<ul>");
            description.AppendLine($"<li>{BuildLink(_appSettings.SCPProcedureUrl, "Security Certification Procedures")}</li>");
            description.AppendLine($"<li>{BuildLink(_appSettings.SCPFaqsUrl, "Certification FAQ's")}</li>");
            description.AppendLine("</ul>");

            description.AppendLine("<p>Please let me know if you have any questions or concerns<br />Cheers,</p>");
            description.AppendLine("</div>");

            return description.ToString();
        }

        private string BuildFreshServiceTicketUrl(string ticketNumber)
        {
            if (string.IsNullOrWhiteSpace(_appSettings.FSTicketUrl) || string.IsNullOrWhiteSpace(ticketNumber))
                return string.Empty;

            return $"{_appSettings.FSTicketUrl.TrimEnd('/')}/{Uri.EscapeDataString(ticketNumber)}";
        }

        private string BuildSharePointFolderUrl(string groupDisplayName, string ticketNumber)
        {
            var segments = new[]
            {
                _sharepointSettings.DocumentSegment,
                _sharepointSettings.BasePath,
                groupDisplayName,
                ticketNumber
            };

            var encodedPath = string.Join("/", segments
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .SelectMany(s => s.Split('/', StringSplitOptions.RemoveEmptyEntries))
                .Select(Uri.EscapeDataString));

            return $"{_sharepointSettings.SiteUrl.TrimEnd('/')}/{encodedPath}";
        }

        private static string BuildServerSection(List<ServerDTO> servers)
        {
            if (servers is null || servers.Count == 0)
                return "N/A";

            var body = new StringBuilder();
            body.AppendLine("<ul>");
            foreach (var server in servers)
            {
                var applicationTeams = BuildDistinctList(server.ServerTeams ?? new List<string>());
                body.AppendLine("<li style='margin-bottom: 10px;'>");
                body.AppendLine($"Device: {Html(server.Name)} - IP: {Html(server.IpAddress)}<br />");
                body.AppendLine($"Server Custodian: {Html(string.IsNullOrWhiteSpace(server.ServerCustodian) ? "N/A" : server.ServerCustodian)}<br />");
                body.AppendLine($"Business Owner: {Html(string.IsNullOrWhiteSpace(server.BusinessOwner) ? "N/A" : server.BusinessOwner)}<br />");
                body.AppendLine($"Application Team(s): {Html(applicationTeams)}");
                body.AppendLine("</li>");
            }

            body.AppendLine("</ul>");
            return body.ToString();
        }

        private static string BuildDistinctList(IEnumerable<string?> values)
        {
            var distinctValues = values.Where(v => !string.IsNullOrWhiteSpace(v))
                                       .Select(v => v!.Trim())
                                       .Distinct(StringComparer.OrdinalIgnoreCase)
                                       .ToList();

            return distinctValues.Count == 0 ? "N/A" : string.Join(", ", distinctValues);
        }

        private static string BuildLink(string url, string text)
        {
            if (string.IsNullOrWhiteSpace(url))
                return Html(text);

            return $"<a href='{HtmlAttribute(url)}' target='_blank'>{Html(text)}</a>";
        }

        private static string Html(string? value) => WebUtility.HtmlEncode(value ?? string.Empty);

        private static string HtmlAttribute(string? value) => Html(value).Replace("'", "&#39;");

        public async Task<List<string>> SearchEmailsAsync(string searchKey, int maxRecordToFetch)
        {
            if (string.IsNullOrWhiteSpace(searchKey) || maxRecordToFetch <= 0)
                return new List<string>();

            var escapedSearchKey = searchKey.Trim().Replace("'", "''");
            var query = $"$filter=contains(PrimaryEmail, '{escapedSearchKey}')&$top={maxRecordToFetch}";

            try
            {
                var response = await _fsRoContext.Users.QueryAsync(query);
                if (!response.IsSuccess || response.Data?.Value is null)
                    return new List<string>();

                return response.Data.Value
                    .Select(user => user.PrimaryEmail)
                    .Where(email => !string.IsNullOrWhiteSpace(email))
                    .Select(email => email.Trim())
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .Take(maxRecordToFetch)
                    .ToList();
            }
            catch
            {
                return new List<string>();
            }
        }
    }
}
