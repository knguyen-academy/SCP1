﻿using Application.DTOs.Request;
using Application.DTOs.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services.FreshServices
{
    public interface IFreshService 
    {
        public Task<long> CreateTicketAsync(string requesterId, List<ServerDTO> servers, UserGroupDTO userGroup, string? userNote);
        public Task<long> CloseFSTicketAsync(string ticketId);
        public Task<long?> GetFsUserIdAsync(string requesterId);
        public Task<List<string>> GetFsGroupsByFsUserIdAsync(long freshServiceUserId);
        public Task<List<string>> SearchEmailsAsync(string searchKey, int maxRecordToFetch);
    }
}
