﻿using Application.Common.Lookups;
using Application.Persistence.SCR;
using Microsoft.EntityFrameworkCore;

namespace Application.Services.Servers
{
    public class ServerService
    {
        private readonly SCRContext _db;
        public ServerService(SCRContext db)
        {
            _db = db;
        }

        public async Task<string?> GetActiveIpInUseAsync(string ipAddress, int? excludeServerId = null)
        {

            if (string.IsNullOrWhiteSpace(ipAddress))
                return null;

            var servers = _db.Server.Where(s => s.IsActive && s.IpAddress == ipAddress.Trim());

            if(excludeServerId.HasValue)
                servers = servers.Where(s=>s.Id != excludeServerId.Value);

            return await servers.Select(s => s.Name).FirstOrDefaultAsync();
       
        }

        public async Task<Dictionary<string, string>> GetActiveIpInUseAsync(IEnumerable<string> ipAddresses, int? excludeServerId =null)
        {
            var ips = ipAddresses?
                      .Where(i => !string.IsNullOrWhiteSpace(i))
                      .Select(i=> i.Trim())
                      .Distinct(StringComparer.OrdinalIgnoreCase)
                      .ToList() ?? new List<string> ();
            if(ips.Count() ==0)
                return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            var servers = _db.Server.Where(s=>s.IsActive && ips.Contains(s.IpAddress));

            if (excludeServerId.HasValue)
                servers = servers.Where(s=>s.Id != excludeServerId.Value);

            var results = await servers.Select(s => new { s.IpAddress, s.Name }).ToListAsync();
            return results.GroupBy(x => x.IpAddress, StringComparer.OrdinalIgnoreCase)
                          .ToDictionary(g => g.Key, g => g.Select(x => x.Name).FirstOrDefault() ?? string.Empty, StringComparer.OrdinalIgnoreCase);
        }

        public async Task DeactivateActiveServersByIpAsync(string ipAddress)
        {
            if (string.IsNullOrWhiteSpace(ipAddress)) 
                return;

            var servers = await _db.Server
                                    .Where(x => x.IsActive && x.IpAddress == ipAddress.Trim())
                                    .ToListAsync();
            if (servers.Count == 0)
                return;

            //var affectedRequestIds = servers.Select(s=>s.RequestId).Distinct().ToList();

            foreach (var server in servers)
            {
                server.IsActive = false;
            }
            await _db.SaveChangesAsync();

            //await CloseRequestWithNoActiveServersAsync(affectedRequestIds);
        }

        private async Task CloseRequestWithNoActiveServersAsync(List<int> requestIds)
        {
            if(requestIds.Count == 0) return;
            foreach(var requestId in requestIds)
            {
                var hasActive = await _db.Server.AsNoTracking().AnyAsync(s=>s.RequestId == requestId && s.IsActive);
                if(hasActive)
                    continue;

                var request = await _db.CertificationRequest.FirstOrDefaultAsync(r=>r.Id == requestId);
                if (request is null)
                    continue;

                //if (request.StatusId == (int)StatusLookup.Closed || request.StatusId == (int)StatusLookup.Cancelled)
                //    continue;

                request.StatusId = (int)StatusLookup.Closed;
                request.CloseDate = DateTime.UtcNow;
            }
            await _db.SaveChangesAsync();
        }
    }
}
