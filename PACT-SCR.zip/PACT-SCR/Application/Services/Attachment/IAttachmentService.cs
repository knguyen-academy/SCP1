﻿using Application.Common.Results;
using Application.DTOs.Attachments;

namespace Application.Services.Attachment
{
    public interface IAttachmentService
    {
        Task<Result> UploadAsync(string groupDisplayName, Guid RequestId, List<AttachmentModel> Attachments, bool folderAlreadyPrepared = false);
        Task<Result> DeleteAsync(string groupDisplayName, Guid tempRequestId, string fileName);
        Task<Result<List<AttachmentModel>>> GetExistingFilesAsync(string groupDisplayName, Guid tempRequestId);
        Task<Result> MoveForCreateAsync(string groupDisplayName, Guid tempRequestId, string fsTicketId );
        Task<Result> MoveForCloseAsync(string groupDisplayName, string fsTicketId);
        Task<Result> MoveForCancelAsync(string groupDisplayName, string fsTicketId);
        Task TryDeleteTempFolderAsync(string groupDisplayName, Guid tempRequestId);
        Task<Result> EnsureTicketFolderAsync(string groupDisplayName, string fsTicketId);
        Task<Result> CreateOldReportFolderAsync(string groupDisplayName, string fsTicketId);
        Task<Result> CopyMasterFileAsync(string groupDisplayName, string fsTicketId, DateTime requestDate);
        Task<Result> GrantRequestFolderAccessAsync(string groupDisplayName, string fsTicketId, List<string> emails);
        Task<Result> GrantCertifiedFolderAccessAsync(string groupDisplayName, string fsTicketId, List<string> emails);
        Task<Result> RevokeArchivedFolderAccessAsync(string groupDisplayName, string fsTicketId);
        Task<Result> RegrantRequestFolderForNewContactsAsync(string groupDisplayName, string fsTicketId, List<string> emails);
        Task PrepareUploadFolderAsync(string groupDisplayName, Guid tempRequestId);
        Task PreConfigSharepointApiAsync();
    }
}





