﻿using Application.Common.Errors;
using Application.Common.Lookups;
using Application.Common.Results;
using Application.DTOs.Attachments;
using Application.Services.CyberArk;
using Application.Settings;
using Azure.Identity;
using Microsoft.Extensions.Options;
using Microsoft.Graph;
using Microsoft.Graph.Drives.Item.Items.Item.Copy;
using Microsoft.Graph.Drives.Item.Items.Item.CreateUploadSession;
using Microsoft.Graph.Drives.Item.Items.Item.Invite;
using Microsoft.Graph.Models;
namespace Application.Services.Attachment
{
    public class SharePointAttachmentService : IAttachmentService
    {
        private readonly IOptionsSnapshot<SharePointSetting> _sharePointConfig;
        private readonly IOptionsSnapshot<UploadFileSetting> _uploadConfig;
        private readonly CyberArkService _cyberArkService;
        private GraphServiceClient? _graphServiceClient;
        private readonly SemaphoreSlim _initLock = new SemaphoreSlim(1, 1);

        public SharePointAttachmentService(IOptionsSnapshot<SharePointSetting> sharePointConfig,
                                            IOptionsSnapshot<UploadFileSetting> uploadConfig,
                                            CyberArkService cyberArkService)
        {
            _sharePointConfig = sharePointConfig;
            _uploadConfig = uploadConfig;
            _cyberArkService = cyberArkService;
        }

        private SharePointSetting _sharePointSetting => _sharePointConfig.Value;
        private UploadFileSetting _uploadSetting => _uploadConfig.Value;
        private string DriveId => _sharePointSetting.DriveId;

        private async Task<GraphServiceClient> GetGraphClientAsync()
        {
            if (_graphServiceClient is not null)
                return _graphServiceClient;

            await _initLock.WaitAsync();
            try
            {
                if (_graphServiceClient is not null)
                    return _graphServiceClient;

                var sharePointCredentialFromCyberArk = await _cyberArkService.GetSharePointApiCredentialsAsync();

                var azureCredential = new ClientSecretCredential(
                    sharePointCredentialFromCyberArk.TenantId,
                    sharePointCredentialFromCyberArk.ClientId,
                    sharePointCredentialFromCyberArk.ClientSecret);

                _graphServiceClient = new GraphServiceClient(azureCredential, new[] { "https://graph.microsoft.com/.default" });
                return _graphServiceClient;
            }
            finally
            {
                _initLock.Release();
            }
        }

        public async Task<Result> UploadAsync(string groupDisplayName, Guid requestId, List<AttachmentModel> attachments, bool folderAlreadyPrepared = false)
        {
            if (attachments is null || attachments.Count == 0)
            {
                return Result.Failure(AppErrors.NoFiles());
            }

            var pending = attachments.Where(f => f.Status == AttachmentStatus.Pending).ToList();
            if (pending.Count == 0)
                return Result.Success();

            foreach (var file in pending)
            {
                if (file.Content is null || file.Content.Length == 0)
                    return Result.Failure(AppErrors.NoFiles());

                var ext = Path.GetExtension(file.Name).ToLowerInvariant();
                if (!_uploadSetting.AllowedFileExtensions.Contains(ext))
                    return Result.Failure(AppErrors.NotAllowedExtension(ext));

                if (file.Content.Length > _uploadSetting.MaxFileSize)
                    return Result.Failure(AppErrors.FileTooLarge(file.Content.Length, _uploadSetting.MaxFileSize));
            }

            var folderPath = BuildPath(groupDisplayName, "Temp", requestId.ToString());

            GraphServiceClient graphClient;
            try
            {
                graphClient = await GetGraphClientAsync();

                if (!folderAlreadyPrepared)
                {
                    await EnsureFolderByPathAsync(folderPath);
                }
            }

            catch (Microsoft.Graph.Models.ODataErrors.ODataError)
            {
                return Result.Failure(AppErrors.UploadFailed(pending[0].Name));
            }
            catch (TimeoutException)
            {
                return Result.Failure(AppErrors.UploadFailed($"{pending[0].Name} (SharePoint timed out)"));
            }
            catch (Exception)
            {
                return Result.Failure(AppErrors.UploadFailed(pending[0].Name));
            }

            // Upload in parallel
            var results = await Task.WhenAll(pending.Select(file =>
                PutFileContentAsync(graphClient, folderPath, file.Name, file.Content!)));

            if (folderAlreadyPrepared && results.Any(r => !r.IsSuccess))
            {
                try
                {
                    await EnsureFolderByPathAsync(folderPath);
                }
                catch
                {
                    // If ensure itself blows up, the original failures will be reported.
                }

                var retryIdx = Enumerable.Range(0, results.Length).Where(i => !results[i].IsSuccess).ToArray();
                var retry = await Task.WhenAll(retryIdx.Select(i =>
                    PutFileContentAsync(graphClient, folderPath, pending[i].Name, pending[i].Content!)));
                for (var k = 0; k < retryIdx.Length; k++)
                    results[retryIdx[k]] = retry[k];
            }

            var firstFailure = results.FirstOrDefault(r => !r.IsSuccess);
            return firstFailure ?? Result.Success();
        }

        // Files up to this size use a single PUT; larger files use a resumable upload session
        private const int LargeFileThresholdBytes = 4 * 1024 * 1024;

        // Hard per-file timeout. 
        private static readonly TimeSpan PerFileUploadTimeout = TimeSpan.FromMinutes(5);

        private async Task<Result> PutFileContentAsync(GraphServiceClient graphClient, string folderPath, string fileName, byte[] fileContent)
        {
            using var cts = new CancellationTokenSource(PerFileUploadTimeout);
            try
            {
                var filePath = $"{folderPath}/{fileName}";
                using var stream = new MemoryStream(fileContent);
                if (fileContent.Length <= LargeFileThresholdBytes)
                {
                    // Small file: simple PUT
                    await graphClient.Drives[DriveId]
                        .Root
                        .ItemWithPath(filePath)
                        .Content
                        .PutAsync(stream, cancellationToken: cts.Token);
                }
                else
                {

                    // Large file: resumable upload session 
                    var sessionBody = new CreateUploadSessionPostRequestBody
                    {
                        Item = new DriveItemUploadableProperties
                        {
                            AdditionalData = new Dictionary<string, object>
                            {
                                { "@microsoft.graph.conflictBehavior", "replace" }
                            }
                        }
                    };
                    var session = await graphClient.Drives[DriveId]
                        .Root
                        .ItemWithPath(filePath)
                        .CreateUploadSession
                        .PostAsync(sessionBody, cancellationToken: cts.Token);

                    // Slice size must be a multiple of 320 KB. 3.2 MB is a good balance.
                    const int sliceSize = 320 * 1024 * 10;
                    var uploader = new LargeFileUploadTask<DriveItem>(session, stream, sliceSize, graphClient.RequestAdapter);
                    await uploader.UploadAsync();
                }
                return Result.Success();
            }
            catch (OperationCanceledException)
            {
                return Result.Failure(AppErrors.UploadFailed($"{fileName} (timed out)"));
            }
            catch (TimeoutException)
            {
                return Result.Failure(AppErrors.UploadFailed($"{fileName} (SharePoint timed out)"));
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError)
            {
                return Result.Failure(AppErrors.UploadFailed(fileName));
            }
            catch (Exception)
            {
                // Catch-all so a single bad file can't abort the Task.
                return Result.Failure(AppErrors.UploadFailed(fileName));
            }
        }

        public async Task<Result> CopyMasterFileAsync(string groupDisplayName, string fsTicketId, DateTime requestDate)
        {
            try
            {
                var graphClient = await GetGraphClientAsync();
                var masterFilePath = _sharePointSetting.MasterFindingSheetFilePath;
                var masterItem = await GetItemByPathAsync(masterFilePath);
                if (masterItem is null)
                    return Result.Failure(AppErrors.MasterFileNotFound(masterFilePath));

                var destFolderPath = BuildPath(groupDisplayName, fsTicketId);
                var destFolder = await EnsureFolderByPathAsync(destFolderPath);

                var extension = Path.GetExtension(masterItem.Name);
                var newFileName = $"SR-{fsTicketId}_{requestDate:MM_dd_yyyy}{extension}";

                var copyBody = new CopyPostRequestBody
                {
                    ParentReference = new ItemReference
                    {
                        DriveId = DriveId,
                        Id = destFolder.Id
                    },
                    Name = newFileName
                };

                await graphClient.Drives[DriveId]
                    .Items[masterItem.Id]
                    .Copy
                    .PostAsync(copyBody);

                return Result.Success();

            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                return Result.Failure(AppErrors.MasterFileCopyFailed(ex.Message));
            }
        }

        public async Task<Result> CreateOldReportFolderAsync(string groupDisplayName, string fsTicketId)
        {
            try
            {
                var folderPath = BuildPath(groupDisplayName, fsTicketId, "Old Reports");
                await EnsureFolderByPathAsync(folderPath);
                return Result.Success();
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                var err = AppErrors.AccessDenied(fsTicketId);
                return Result.Failure(err.Code, err.Message, ex);
            }
        }

        public async Task<Result> DeleteAsync(string groupDisplayName, Guid tempRequestId, string fileName)
        {
            var filePath = BuildPath(groupDisplayName, "Temp", tempRequestId.ToString(), fileName);
            try
            {
                var graphClient = await GetGraphClientAsync();
                var item = await GetItemByPathAsync(filePath);
                if (item is null)
                    return Result.Success();

                await graphClient.Drives[DriveId]
                                  .Items[item.Id]
                                  .DeleteAsync();

                var folderPath = BuildPath(groupDisplayName, "Temp", tempRequestId.ToString());
                await TryDeleteEmptyFolderAsync(folderPath);

                return Result.Success();
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                return Result.Failure(AppErrors.DeleteFailed(fileName));
            }
        }

        public async Task<Result> EnsureTicketFolderAsync(string groupDisplayName, string fsTicketId)
        {
            try
            {
                var folderPath = BuildPath(groupDisplayName, fsTicketId);
                await EnsureFolderByPathAsync(folderPath);
                return Result.Success();
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                var err = AppErrors.AccessDenied(fsTicketId);
                return Result.Failure(err.Code, err.Message, ex);
            }
        }

        public async Task<Result<List<AttachmentModel>>> GetExistingFilesAsync(string groupDisplayName, Guid tempRequestId)
        {
            var folderPath = BuildPath(groupDisplayName, "Temp", tempRequestId.ToString());
            var result = new List<AttachmentModel>();
            try
            {
                var graphClient = await GetGraphClientAsync();
                var folder = await GetItemByPathAsync(folderPath);

                if (folder is null)
                    return Result<List<AttachmentModel>>.Success(result);

                var children = await graphClient.Drives[DriveId]
                    .Items[folder.Id]
                    .Children
                    .GetAsync();

                if (children?.Value is not null)
                {
                    foreach (var item in children.Value.Where(i => i.File != null))
                    {
                        result.Add(new AttachmentModel
                        {
                            Name = item.Name,
                            Size = item.Size ?? 0,
                            FilePath = item.WebUrl
                        });
                    }
                }

                return Result<List<AttachmentModel>>.Success(result);
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                var err = AppErrors.ListFilesFailed();
                return Result<List<AttachmentModel>>.Failure(err.Code, err.Message, ex);
            }
        }

        public async Task<Result> MoveForCancelAsync(string groupDisplayName, string fsTicketId)
        {
            var sourcePath = BuildPath(groupDisplayName, fsTicketId);
            var destPath = BuildPath(groupDisplayName, "Archive", fsTicketId);
            return await MoveSharePointFolderAsync(sourcePath, destPath);
        }

        public async Task<Result> MoveForCloseAsync(string groupDisplayName, string fsTicketId)
        {
            var sourcePath = BuildPath(groupDisplayName, fsTicketId);
            var destPath = BuildPath(groupDisplayName, "Certified", fsTicketId);
            return await MoveSharePointFolderAsync(sourcePath, destPath);
        }

        public async Task<Result> MoveForCreateAsync(string groupDisplayName, Guid tempRequestId, string fsTicketId)
        {
            var sourcePath = BuildPath(groupDisplayName, "Temp", tempRequestId.ToString());
            var destPath = BuildPath(groupDisplayName, fsTicketId);
            return await MoveSharePointFolderAsync(sourcePath, destPath);
        }

        public async Task TryDeleteTempFolderAsync(string groupDisplayName, Guid tempRequestId)
        {
            try
            {
                var graphClient = await GetGraphClientAsync();
                var folderPath = BuildPath(groupDisplayName, "Temp", tempRequestId.ToString());
                var folder = await GetItemByPathAsync(folderPath);
                if (folder != null)
                {
                    await graphClient.Drives[DriveId]
                        .Items[folder.Id]
                        .DeleteAsync();
                }
            }
            catch (Exception)
            {
                //Best effort
            }
        }

        private string BuildPath(params string[] segments)
        {
            var basePath = _sharePointSetting.BasePath.TrimEnd('/');
            var combinePath = string.Join("/", segments.Select(s => s.Trim('/')));
            return string.IsNullOrEmpty(basePath) ? combinePath : $"{basePath}/{combinePath}";
        }

        private async Task<DriveItem?> GetItemByPathAsync(string itemPath)
        {
            try
            {
                var graphClient = await GetGraphClientAsync();
                return await graphClient.Drives[DriveId]
                    .Root
                    .ItemWithPath(itemPath)
                    .GetAsync();
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex) when (ex.ResponseStatusCode == 404)
            {
                return null;
            }
        }


        private async Task<DriveItem> EnsureFolderByPathAsync(string folderPath)
        {
            var graphClient = await GetGraphClientAsync();
            var existingFull = await GetItemByPathAsync(folderPath);
            if (existingFull is not null)
                return existingFull;

            var segments = folderPath.Split('/', StringSplitOptions.RemoveEmptyEntries);
            var currentPath = string.Empty;
            DriveItem? lastCreated = null;

            foreach (var segment in segments)
            {
                currentPath = string.IsNullOrEmpty(currentPath) ? segment : $"{currentPath}/{segment}";

                var existing = await GetItemByPathAsync(currentPath);
                if (existing != null)
                {
                    lastCreated = existing;
                    continue;
                }

                var newFolder = new DriveItem
                {
                    Name = segment,
                    Folder = new Folder(),
                    AdditionalData = new Dictionary<string, object>
                    {
                        {"@microsoft.graph.conflictBehavior", "fail" }
                    }
                };

                var parentId = lastCreated?.Id ?? "root";
                lastCreated = await graphClient.Drives[DriveId]
                                                .Items[parentId]
                                                .Children
                                                .PostAsync(newFolder);
            }
            return lastCreated!;
        }
        private async Task<Result> MoveSharePointFolderAsync(string sourcePath, string destPath)
        {
            try
            {
                var graphClient = await GetGraphClientAsync();
                var sourceFolder = await GetItemByPathAsync(sourcePath);
                if (sourceFolder is null)
                    return Result.Success();

                var existingDest = await GetItemByPathAsync(destPath);

                if (existingDest is null)
                {
                    var lastSlash = destPath.LastIndexOf('/');
                    var destParentPath = lastSlash > 0 ? destPath.Substring(0, lastSlash) : string.Empty;
                    var destName = lastSlash > 0 ? destPath.Substring(lastSlash + 1) : destPath;

                    var destParent = await EnsureFolderByPathAsync(destParentPath);

                    var moveBody = new DriveItem
                    {
                        ParentReference = new ItemReference
                        {
                            DriveId = DriveId,
                            Id = destParent.Id
                        },
                        Name = destName
                    };

                    await graphClient.Drives[DriveId]
                        .Items[sourceFolder.Id]
                        .PatchAsync(moveBody);
                }
                else
                {

                    var childrenPage = await graphClient.Drives[DriveId]
                                                        .Items[sourceFolder.Id]
                                                        .Children
                                                        .GetAsync();

                    var allChildren = new List<DriveItem>();
                    var pageIterator = Microsoft.Graph.PageIterator<DriveItem, DriveItemCollectionResponse>
                        .CreatePageIterator(graphClient, childrenPage, item => { allChildren.Add(item); return true; });
                    await pageIterator.IterateAsync();

                    var moveTasks = allChildren.Select(child =>
                    {
                        var childMoveBody = new DriveItem
                        {
                            ParentReference = new ItemReference
                            {
                                DriveId = DriveId,
                                Id = existingDest.Id
                            }
                        };
                        return graphClient.Drives[DriveId]
                                          .Items[child.Id]
                                          .PatchAsync(childMoveBody);
                    });
                    await Task.WhenAll(moveTasks);

                    await graphClient.Drives[DriveId]
                        .Items[sourceFolder.Id]
                        .DeleteAsync();
                }

                return Result.Success();
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                return Result.Failure(AppErrors.MoveFailed().Code, AppErrors.MoveFailed().Message, ex);
            }
        }
        public async Task TryDeleteEmptyFolderAsync(string folderPath)
        {
            try
            {
                var graphClient = await GetGraphClientAsync();
                var folder = await GetItemByPathAsync(folderPath);
                if (folder is null)
                    return;

                var children = await graphClient.Drives[DriveId]
                                                .Items[folder.Id]
                                                .Children
                                                .GetAsync();
                if (children?.Value == null || children.Value.Count == 0)
                {
                    await graphClient.Drives[DriveId]
                        .Items[folder.Id]
                        .DeleteAsync();
                }
            }
            catch
            {
                //Best effort
            }
        }

        public Task<Result> GrantRequestFolderAccessAsync(string groupDisplayName, string fsTicketId, List<string> emails) =>
            GrantAccessAtPathAsync(BuildPath(groupDisplayName, fsTicketId), fsTicketId, emails);

        public Task<Result> GrantCertifiedFolderAccessAsync(string groupDisplayName, string fsTicketId, List<string> emails) =>
            GrantAccessAtPathAsync(BuildPath(groupDisplayName, "Certified", fsTicketId), fsTicketId, emails);

        public Task<Result> RevokeArchivedFolderAccessAsync(string groupDisplayName, string fsTicketId) =>
            RevokePermissionsAtPathAsync(BuildPath(groupDisplayName, "Archive", fsTicketId), fsTicketId);

        private async Task<Result> GrantAccessAtPathAsync(string folderPath, string fsTicketId, List<string> emails)
        {
            if (emails is null || emails.Count == 0)
                return Result.Success();

            try
            {
                var graphClient = await GetGraphClientAsync();
                var folder = await GetItemByPathAsync(folderPath);

                if (folder is null)
                    return Result.Failure(AppErrors.AccessDenied(fsTicketId));

                var inviteBody = new InvitePostRequestBody
                {
                    Recipients = emails
                                 .Where(e => !string.IsNullOrWhiteSpace(e))
                                 .Select(e => new DriveRecipient { Email = e.Trim() })
                                 .ToList(),
                    Roles = new List<string> { "write" },
                    RequireSignIn = true,
                    SendInvitation = false
                };

                await graphClient.Drives[DriveId]
                                .Items[folder.Id]
                                .Invite
                                .PostAsInvitePostResponseAsync(inviteBody);
                return Result.Success();
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                return Result.Failure(AppErrors.AccessDenied(fsTicketId).Code, ex.Message, ex);
            }
        }

        private async Task<Result> RevokePermissionsAtPathAsync(string folderPath, string fsTicketId)
        {
            try
            {
                var graphClient = await GetGraphClientAsync();
                var folder = await GetItemByPathAsync(folderPath);

                if (folder is null)
                    return Result.Success(); // folder doesn't exist, nothing to revoke

                var permissions = await graphClient.Drives[DriveId]
                    .Items[folder.Id]
                    .Permissions
                    .GetAsync();

                if (permissions?.Value is null)
                    return Result.Success();

                var directPermissions = permissions.Value.Where(p => p.InheritedFrom == null).ToList();
                var deleteTasks = directPermissions.Select(async permission =>
                {
                    try
                    {
                        await graphClient.Drives[DriveId]
                            .Items[folder.Id]
                            .Permissions[permission.Id]
                            .DeleteAsync();
                    }
                    catch (Microsoft.Graph.Models.ODataErrors.ODataError)
                    {
                        // System / owner permission isn't deletable — ignore.
                    }
                });
                await Task.WhenAll(deleteTasks);

                return Result.Success();
            }
            catch (Microsoft.Graph.Models.ODataErrors.ODataError ex)
            {
                return Result.Failure(AppErrors.AccessDenied(fsTicketId).Code, ex.Message, ex);
            }
        }

        public async Task PrepareUploadFolderAsync(string groupDisplayName, Guid tempRequestId)
        {
            try
            {
                var folderPath = BuildPath(groupDisplayName, "Temp", tempRequestId.ToString());
                await EnsureFolderByPathAsync(folderPath);
            }
            catch
            {
                //Best-effort
            }
        }

        public async Task PreConfigSharepointApiAsync()
        {
            try
            {
                var graphClient = await GetGraphClientAsync();
                await graphClient.Drives[DriveId].Root.GetAsync();
            }
            catch
            {
                //Best-effort
            }
        }

        public async Task<Result> RegrantRequestFolderForNewContactsAsync(string groupDisplayName, string fsTicketId, List<string> emails)
        {
            var folderPath = BuildPath(groupDisplayName, fsTicketId);

            var revokeResult = await RevokePermissionsAtPathAsync(folderPath, fsTicketId);
            if (!revokeResult.IsSuccess)
                return revokeResult;

            return await GrantAccessAtPathAsync(folderPath, fsTicketId, emails);
        }
    }
}