﻿using Application.DTOs.Request;
using Application.Entities.SCR;
using Application.Settings;
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.Graph.Models;
using Package.Emails;
using Package.Emails.Models;
using System.Net;
using System.Text;

namespace Application.Services.Email
{
    public class SOCEmailService
    {
        private readonly EmailService _emailService;
        private readonly AppSetting _appOptions;
        private readonly SharePointSetting _sharePointOptions;
        private readonly EmailSetting _emailOptions;
        private readonly NavigationManager _navigation;
        private readonly IHostEnvironment _hostEnv;

        public SOCEmailService(EmailService emailService, 
                               IOptions<EmailSetting> emailOptions, 
                               IOptions<AppSetting> appOptions, 
                               IOptions<SharePointSetting> sharePointOptions,
                               NavigationManager Navigation, 
                               IHostEnvironment hostEnv)
        {
            _emailService = emailService;
            _appOptions = appOptions.Value;
            _emailOptions = emailOptions.Value;
            _sharePointOptions = sharePointOptions.Value;
            _navigation = Navigation;
            _hostEnv = hostEnv;
        }

        public async Task SendConfirmEmailAsync(int requestId, string ticketNumber, string groupDisplayName, List<ServerDTO> servers, string? note, List<string> to, List<string>? cc)
        {
            var from = _emailOptions.From;

            if (cc is null)
                cc = to;

            string subject = $"Security Certification Request #{requestId} Created";
            StringBuilder body = new StringBuilder();
            var ticketUrl = BuildFreshTicketUrl(ticketNumber);
            var sharePointFolderUrl = BuildSharePointFolderUrl(groupDisplayName, ticketNumber);
            var noteText = string.IsNullOrWhiteSpace(note) ? "N/A" : note;

            body.AppendLine($"<table>");
            
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine("<p>Hello,</p>");
            body.AppendLine($"<p>A new security certification request has been created. Your participation may be required. Please follow the link below to view the service request.</p>");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"<b>Next Steps</b>:");
            body.AppendLine($"<ul>");
            body.AppendLine($"<li>Soc will scan the device(s) and fill out the findings sheet.</li>");
            body.AppendLine($"<li>You will be notified once the initial scan has been completed and findings have been documented.</li>");
            body.AppendLine($"</ul>");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"<b>Security Certification Request</b>: {BuildLink(ticketUrl, string.IsNullOrWhiteSpace(ticketNumber) ? $"Request #{requestId}" : ticketNumber)}<br />");
            body.AppendLine($"<b>Security Finding Sheet</b>: {BuildLink(sharePointFolderUrl, "SharePoint folder")}<br />");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"<b>Server(s)</b>");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine(BuildServerSection(servers));
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"<b>Note</b>: {noteText}");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"<b>Expectations</b>:");
            body.AppendLine($"<ul>");
            body.AppendLine($"<li>Server certification request should be completed within 5 business days. If there is no progress in remediating security findings after 5 business days, Security may request to shut down the systems.</li>");
            body.AppendLine($"<li>Systems should not be in production until they have been certified.</li>");
            body.AppendLine($"</ul>");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"<b>Procedures and FAQ's.</b>:");
            body.AppendLine($"<ul>");
            body.AppendLine($"<li>{BuildLink(_appOptions.SCPProcedureUrl, "Security Certification Procedures")}</li>");
            body.AppendLine($"<li>{BuildLink(_appOptions.SCPFaqsUrl, "Certification FAQ's")}</li>");
            body.AppendLine($"</ul>");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"</table>");
            var email = new EmailRequest
            {
                From = from,
                To = to,
                Cc = cc,
                Subject = subject,
                HtmlBody = body.ToString(),
            };

            var response = await _emailService.SendAsync(email);
        }

        private string? BuildServerSection(List<ServerDTO> servers)
        {
            if (servers is null || servers.Count == 0)
                return "N/A";

            var body = new StringBuilder();

            body.AppendLine("<ul>");
            
            foreach(var server in servers)
            {
                var applicationTeams = BuildDistinctList(server.ServerTeams ?? new List<string>());
                body.AppendLine("<li style='margin-bottom: 10px;'>");
                body.AppendLine($"Device: {server.Name}  -  IP: {server.IpAddress}<br />");
                body.AppendLine($"Server Custodian: {server.ServerCustodian}<br />");
                body.AppendLine($"Business Owner: {server.BusinessOwner}<br />");
                body.AppendLine($"Application Team(s): {applicationTeams}");
                body.AppendLine("</li>");
            }

            body.AppendLine("</ul>");
            return body.ToString();
        }

        private static string BuildDistinctList(IEnumerable<string?> values)
        {
            var distinctValues = values.Where(x => !string.IsNullOrWhiteSpace(x))
                                       .Select(x => x!.Trim())
                                       .Distinct(StringComparer.OrdinalIgnoreCase)
                                       .ToList();

            return distinctValues.Count == 0 ? "N/A" : string.Join(", ", distinctValues);
        }


        private static string BuildLink(string url, string text)
        {
            if (string.IsNullOrWhiteSpace(url))
                return Html(text);

            return $"<a href='{HtmlAttribute(url)}' target='_blank'>{Html(text)}</a>";
        }

        private static string Html(string? value) => WebUtility.HtmlEncode(value ?? string.Empty);
        private static string HtmlAttribute(string? value) => Html(value).Replace("'", "&#39;");

        private string BuildSharePointFolderUrl(string groupDisplayName, string ticketNumber)
        {
            var segments = new[]
            {
                _sharePointOptions.DocumentSegment,
                _sharePointOptions.BasePath,
                groupDisplayName,
                ticketNumber
            };

            var encodedPath = string.Join("/", segments
                                    .Where(s => !string.IsNullOrWhiteSpace(s))
                                    .SelectMany(s => s.Split('/', StringSplitOptions.RemoveEmptyEntries))
                                    .Select(Uri.EscapeDataString));

            return $"{_sharePointOptions.SiteUrl.TrimEnd('/')}/{encodedPath}";
        }

        private string BuildFreshTicketUrl(string ticketNumber)
        {
            if (string.IsNullOrWhiteSpace(_appOptions.FSTicketUrl) || string.IsNullOrWhiteSpace(ticketNumber))
                return $"{_navigation.BaseUri}summary";

            return $"{_appOptions.FSTicketUrl.TrimEnd('/')}/{Uri.EscapeDataString(ticketNumber)}";
        }

        public async Task SendISOUEmailAsync(string requesterName, int requestId, List<Server> servers)
        {
            if (servers is null || servers.Count == 0)
                return;

            var from = _emailOptions.SOCEmail;

            List<string> to = new List<string> { _emailOptions.ISOUEmail };
            List<string>? cc = new List<string> { _emailOptions.SOCEmail };

            string subject = $"IP Exception, incorrect zoning";
            StringBuilder body = new StringBuilder();

            body.AppendLine($"<table>");
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"ISOU,");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"Listed below are server(s) that <b>{requesterName}</b> has created an exception for not being zoned properly.");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"If this has not been approved please notify <b>SOC</b> so we can get issues resolved.");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            servers.ForEach(server =>
            {
                body.AppendLine($"<tr>");
                body.AppendLine($"<td style='padding-bottom: 15px;'>");
                body.AppendLine($"<ul>");
                body.AppendLine($"<li>");
                body.AppendLine($"{server.Name} - {server.IpAddress}");
                body.AppendLine($"<ul>");
                body.AppendLine($"<li>");
                body.AppendLine($"<b>Reason</b>: {server.Reason}");
                body.AppendLine($"</li>");
                body.AppendLine($"<li>");
                body.AppendLine($"<b>Justification</b>: {server.Justification}");
                body.AppendLine($"</li>");
                body.AppendLine($"</ul>");
                body.AppendLine($"</li>");
                body.AppendLine($"</ul>");
                body.AppendLine($"</td>");
                body.AppendLine($"</tr>");

            });

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"Pleas reply to this email to approve or deny the request.");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine("SOC.");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            body.AppendLine($"</table>");

            var email = new EmailRequest
            {
                From = from,
                To = to,
                Cc = cc,
                Subject = subject,
                HtmlBody = body.ToString(),
            };

            var response = await _emailService.SendAsync(email);
        }

        public async Task SendSOCEmailAsync(int requestId, List<ServerDTO> servers)
        {
            var from = _emailOptions.From;
            List<string> to = new List<string> { _emailOptions.SOCEmail };
            List<string>? cc = new List<string> { _emailOptions.SOCEmail };

            string subject = $"IP Exception, incorrect zoning";
            StringBuilder body = new StringBuilder();

            body.AppendLine($"<table>");
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"SOC,");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"ISOU has the IP Exception with the following reason and justification.");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"Request ID : {requestId}");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            servers.ForEach(server =>
            {
                body.AppendLine($"<tr>");
                body.AppendLine($"<td style='padding-bottom: 15px;'>");
                body.AppendLine($"<ul>");
                body.AppendLine($"<li>");
                body.AppendLine($"{server.Name} - {server.IpAddress}");
                body.AppendLine($"<ul>");
                body.AppendLine($"<li>");
                body.AppendLine($"<b>Reason</b>: {server.Reason}");
                body.AppendLine($"</li>");
                body.AppendLine($"<li>");
                body.AppendLine($"<b>Justification</b>: {server.Justification}");
                body.AppendLine($"</li>");
                body.AppendLine($"</ul>");
                body.AppendLine($"</li>");
                body.AppendLine($"</ul>");
                body.AppendLine($"</td>");
                body.AppendLine($"</tr>");
            });
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine("ISOU");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            body.AppendLine($"</table>");

            var email = new EmailRequest
            {
                From = from,
                To = to,
                Cc = cc,
                Subject = subject,
                HtmlBody = body.ToString(),
            };

            var response = await _emailService.SendAsync(email);
        }

        public async Task SendCertifyEmailAsync(int requestId, string requesterEmail, List<string> serverContacts)
        {
            var from = _emailOptions.From;

            var to = _hostEnv.IsProduction()
                    ? new List<string> { _emailOptions.SOCEmail }
                    : new List<string> { requesterEmail };

            var cc = serverContacts.Count > 0 ? serverContacts : null;


            string subject = $"Security Certification Request #{requestId} - Certified";
            StringBuilder body = new StringBuilder();

            body.AppendLine($"<table>");
            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"Security Certification Request <b>#{requestId}</b> has been certified.");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine($"Click <a href='{_navigation.BaseUri}summary' target='_blank'>here</a> to view the request.");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");

            body.AppendLine($"<tr>");
            body.AppendLine($"<td style='padding-bottom: 15px;'>");
            body.AppendLine("SOC");
            body.AppendLine($"</td>");
            body.AppendLine($"</tr>");
            body.AppendLine($"</table>");

            var email = new EmailRequest
            {
                From = from,
                To = to,
                Cc = cc,
                Subject = subject,
                HtmlBody = body.ToString(),
            };

            var response = await _emailService.SendAsync(email);
        }
    }
}
