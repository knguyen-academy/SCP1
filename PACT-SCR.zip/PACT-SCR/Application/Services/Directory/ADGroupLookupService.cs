﻿using System.Net.Mail;
using Microsoft.Extensions.Logging;

namespace Application.Services.Directory;

public record ADGroupLookupResult(
    bool IsSuccess,
    string Message,
    IReadOnlyList<string>? Emails = null);

public class ADGroupLookupService
{
    private readonly ActiveDirectoryClientFactory _factory;
    private readonly ILogger<ADGroupLookupService> _logger;

    public ADGroupLookupService(
        ActiveDirectoryClientFactory factory,
        ILogger<ADGroupLookupService> logger)
    {
        _factory = factory;
        _logger = logger;
    }

    public async Task<ADGroupLookupResult> LookupAsync(string email)
    {
        email = email.Trim();

        if (!MailAddress.TryCreate(email, out var address) ||
            !string.Equals(
                address.Address,
                email,
                StringComparison.OrdinalIgnoreCase))
        {
            return new(false, "Enter a valid group email address.");
        }

        if (!OperatingSystem.IsWindows())
            return new(false, "The AD lookup requires Windows.");

        var stage = "retrieving AD credentials from CyberArk";

        try
        {
            var reader = await _factory.CreateAsync();

            stage = "reading AD group membership";

            var emails = await Task.Run(
                () => reader.GetGroupMemberEmailsByEmail(email));

            return new(
                true,
                $"Found {emails.Count} distinct member email addresses.",
                emails);
        }
        catch (InvalidOperationException ex)
            when (stage == "reading AD group membership")
        {
            return new(false, ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                "AD lookup failed while {Stage}: {ExceptionType}",
                stage,
                ex.GetType().Name);

            return new(
                false,
                $"Failed while {stage} ({ex.GetType().Name}). " +
                "Check the CyberArk IDs, credential permissions, " +
                "AD domain, and network connectivity.");
        }
    }
}