﻿using System.DirectoryServices;

namespace Application.Services.Directory;

public class ADGroupReader
{
    private readonly string _username;
    private readonly string _password;
    private readonly string _domain;

    public ADGroupReader(
        string username,
        string password,
        string domain)
    {
        if (Uri.CheckHostName(domain) != UriHostNameType.Dns)
            throw new ArgumentException("Invalid AD domain.", nameof(domain));

        _username = username;
        _password = password;
        _domain = domain;
    }

    public List<string> GetGroupMemberEmailsByEmail(string groupEmail)
    {
        if (string.IsNullOrWhiteSpace(groupEmail))
            throw new ArgumentException(
                "Group email is required.", nameof(groupEmail));

        var baseDn = string.Join(",",
            _domain.Split('.').Select(part => $"DC={part}"));

        using var root = new DirectoryEntry(
            $"LDAP://{_domain}/{baseDn}",
            _username,
            _password,
            AuthenticationTypes.Secure);

        var email = EscapeFilterValue(groupEmail.Trim());

        using var groupSearch = new DirectorySearcher(root)
        {
            Filter =
                $"(&(objectCategory=group)(|(mail={email})(proxyAddresses=smtp:{email})))",
            ClientTimeout = TimeSpan.FromSeconds(30)
        };

        groupSearch.PropertiesToLoad.Add("distinguishedName");

        using var groups = groupSearch.FindAll();

        if (groups.Count == 0)
            throw new InvalidOperationException(
                "No AD group matches this email.");

        if (groups.Count > 1)
            throw new InvalidOperationException(
                "Multiple AD groups match this email.");

        var groupDn = groups[0]
            .Properties["distinguishedName"][0].ToString();

        if (string.IsNullOrWhiteSpace(groupDn))
            throw new InvalidOperationException(
                "The group distinguished name is unavailable.");

        using var memberSearch = new DirectorySearcher(root)
        {
            Filter =
                "(&(objectCategory=person)(objectClass=user)" +
                $"(memberOf:1.2.840.113556.1.4.1941:={EscapeFilterValue(groupDn)}))",
            PageSize = 500,
            ReferralChasing = ReferralChasingOption.None,
            ClientTimeout = TimeSpan.FromSeconds(30)
        };

        memberSearch.PropertiesToLoad.Add("mail");
        memberSearch.PropertiesToLoad.Add("sAMAccountName");

        using var members = memberSearch.FindAll();

        var emails = new HashSet<string>(
            StringComparer.OrdinalIgnoreCase);

        foreach (SearchResult member in members)
        {
            if (member.Properties["mail"].Count == 0)
            {
                var account = member.Properties["sAMAccountName"]
                    .Cast<object>().FirstOrDefault()?.ToString();

                throw new InvalidOperationException(
                    $"AD member has no email: {account ?? "unknown"}.");
            }

            var memberEmail = member.Properties["mail"][0]?.ToString();

            if (string.IsNullOrWhiteSpace(memberEmail))
                throw new InvalidOperationException(
                    "An AD member has an empty email address.");

            emails.Add(memberEmail.Trim());
        }

        return emails
            .OrderBy(value => value, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static string EscapeFilterValue(string value)
    {
        return value
            .Replace("\\", "\\5c")
            .Replace("*", "\\2a")
            .Replace("(", "\\28")
            .Replace(")", "\\29")
            .Replace("\0", "\\00");
    }
}