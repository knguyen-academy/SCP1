﻿using Application.Services.CyberArk;
using Application.Settings;
using Microsoft.Extensions.Options;

namespace Application.Services.Directory;

public class ActiveDirectoryClientFactory
{
    private readonly CyberArkService _cyberArk;
    private readonly IOptionsSnapshot<ActiveDirectorySetting> _options;

    public ActiveDirectoryClientFactory(
        CyberArkService cyberArk,
        IOptionsSnapshot<ActiveDirectorySetting> options)
    {
        _cyberArk = cyberArk;
        _options = options;
    }

    public async Task<ADGroupReader> CreateAsync()
    {
        var settings = _options.Value;

        if (settings.ApplicationId <= 0 ||
            settings.CredentialId == Guid.Empty)
        {
            throw new InvalidOperationException(
                "Configure the AD CyberArk ApplicationId and CredentialId.");
        }

        var credential = await _cyberArk.GetCredentialFromCyberArkAsync(
            settings.ApplicationId,
            settings.CredentialId);

        if (credential is null ||
            string.IsNullOrWhiteSpace(credential.Username) ||
            string.IsNullOrEmpty(credential.Password))
        {
            throw new InvalidOperationException(
                "CyberArk did not return an AD username and password.");
        }

        return new ADGroupReader(
            credential.Username,
            credential.Password,
            settings.Domain);
    }
}