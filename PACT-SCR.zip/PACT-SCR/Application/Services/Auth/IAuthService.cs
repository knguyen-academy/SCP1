﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services.Auth
{
    public interface IAuthService
    {
        public Task<string> GetUserFtbId();
        public Task<bool> IsInRole(string roleName);
    }
}
