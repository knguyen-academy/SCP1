﻿using Application.DTOs.Requests;
using Application.Persistence.SCR;
using Application.Services.FreshServices;
using Microsoft.EntityFrameworkCore;

namespace Application.Services.UserGroup
{
    public class UserGroupService
    {
        private readonly IFreshService _freshService;
        private readonly SCRContext _db;
        public UserGroupService(IFreshService freshService, SCRContext db)
        {
            _freshService = freshService;
            _db = db;
        }


        public async Task<UserGroupDTO> GetAppUserGroupByFtbUserIdAsync(string currentFtbUserId)
        {
            var fsUserId = await _freshService.GetFsUserIdAsync(currentFtbUserId);
            List<string> fsFtbUserGroups = await _freshService.GetFsGroupsByFsUserIdAsync(fsUserId.Value);
            List<string> normalizedFsFtbUserGroups = fsFtbUserGroups.Where(x => !string.IsNullOrWhiteSpace(x))
                                                                    .Select(x => x.Trim().ToLower())
                                                                    .ToList();
            var allAppGroups = await _db.Group.ToListAsync();

            var matchedGroup = allAppGroups.FirstOrDefault(g => normalizedFsFtbUserGroups.Contains(g.Value.ToLower()));
            var otherGroup = allAppGroups.FirstOrDefault(g => g.Value.Equals("Other", StringComparison.OrdinalIgnoreCase));

            var result = matchedGroup ?? otherGroup;
            return new UserGroupDTO
            {
                Id = result.Id,
                Value = result.Value,
                DisplayName = result.DisplayName,
            };
        }

    }
}
