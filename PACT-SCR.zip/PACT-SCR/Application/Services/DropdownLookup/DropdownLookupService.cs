﻿using Application.DTOs.Dropdowns;
using Application.Persistence.SCR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Application.Services.DropdownLookup
{
    public class DropdownLookupService : IDropdownLookupService
    {
        private const string AllDropdownDataCacheKey = "SCR.Dropdowns.AllDropdownData.v1";

        private readonly SCRContext _db;
        private readonly IMemoryCache _cache;
        public DropdownLookupService(SCRContext db, IMemoryCache cache)
        {
            _db = db;
            _cache = cache;
        }
        public async Task<AllDropdownDataDTO> GetAllDropdownDataAsync()
        {
            if (_cache.TryGetValue(AllDropdownDataCacheKey, out AllDropdownDataDTO? cached) && cached is not null)
                return cached;

            var freshCallFromDb =  new AllDropdownDataDTO
            {
                Environments = await GetEnvironmentsAsync(),
                Zones = await GetZonesAsync(),
                Os = await GetOsAsync(),
                Devices = await GetDevicesAsync(),
                Hosts = await GetHostsAsync(),
                LifeCycles = await GetLifecyclesAsync(),
                Credentials = await GetCredentialsAsync(),
                Databases = await GetDatabasesAsync()
            };

            _cache.Set(AllDropdownDataCacheKey, freshCallFromDb, TimeSpan.FromMinutes(30));
            return freshCallFromDb;
        }

        public async Task<List<DropdownLookupDTO>> GetCredentialsAsync()
        {
            return await _db.Credential
                        .AsNoTracking()
                        .Select(s => new DropdownLookupDTO(s.Id, s.Value))
                        .ToListAsync();
        }

        public async Task<List<DropdownLookupDTO>> GetDatabasesAsync()
        {
            return await _db.Database
                         .AsNoTracking()
                         .Select(s => new DropdownLookupDTO(s.Id, s.Value))
                         .ToListAsync();
        }

        public async Task<List<DropdownLookupDTO>> GetDevicesAsync()
        {
            return await _db.Device
                          .AsNoTracking() 
                          .Select(s => new DropdownLookupDTO(s.Id, s.Value))
                          .ToListAsync();
        }

        public async Task<List<DropdownLookupDTO>> GetEnvironmentsAsync()
        {
            return await _db.HostEnvironment
                          .AsNoTracking()
                          .Select(s => new DropdownLookupDTO(s.Id, s.Value))
                          .ToListAsync();
        }
        public async Task<List<DropdownLookupDTO>> GetHostsAsync()
        {
            return await _db.Host
                          .AsNoTracking()
                          .Select(s => new DropdownLookupDTO(s.Id, s.Value))
                          .ToListAsync();
        }

        public async Task<List<DropdownLookupDTO>> GetLifecyclesAsync()
        {
            return await _db.Lifecycle
                         .AsNoTracking()
                         .Select(s => new DropdownLookupDTO(s.Id, s.Value))
                         .ToListAsync();
        }

        public async Task<List<DropdownLookupDTO>> GetOsAsync()
        {
            return await _db.Os
                          .AsNoTracking()
                          .Select(s => new DropdownLookupDTO(s.Id, s.Value))
                          .ToListAsync();
        }

        public async Task<List<DropdownLookupDTO>> GetZonesAsync()
        {
            return await _db.Zone
                           .AsNoTracking() 
                           .Select(s => new DropdownLookupDTO(s.Id, $"{s.DisplayName} : {s.Value}"))
                           .ToListAsync();
        }
    }
}
