﻿using Application.DTOs.Dropdowns;

namespace Application.Services.DropdownLookup
{
    public interface IDropdownLookupService
    {
        Task<List<DropdownLookupDTO>> GetEnvironmentsAsync();
        Task<List<DropdownLookupDTO>> GetZonesAsync();
        Task<List<DropdownLookupDTO>> GetOsAsync();
        Task<List<DropdownLookupDTO>> GetDevicesAsync();
        Task<List<DropdownLookupDTO>> GetHostsAsync();
        Task<List<DropdownLookupDTO>> GetLifecyclesAsync();
        Task<List<DropdownLookupDTO>> GetCredentialsAsync();
        Task<List<DropdownLookupDTO>> GetDatabasesAsync();
        Task<AllDropdownDataDTO> GetAllDropdownDataAsync();
    }
}
