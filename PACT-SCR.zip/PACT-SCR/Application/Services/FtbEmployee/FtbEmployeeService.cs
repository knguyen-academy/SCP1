﻿using Application.DTOs.Employees;
using Application.Persistence.DG;
using Application.Persistence.FTBEmployee;
using Application.Services.FreshServices;
using Microsoft.EntityFrameworkCore;

namespace Application.Services.FtbEmployee
{
    public class FtbEmployeeService
    {
        private readonly FTBEmployeeContext _ftbEmpContext;
        private readonly DGPropertiesContext _dgContext;
        private readonly IFreshService _freshService;

        public FtbEmployeeService(FTBEmployeeContext ftbEmpContext, DGPropertiesContext dgContext, IFreshService freshService)
        {
            _ftbEmpContext = ftbEmpContext;
            _dgContext = dgContext;
            _freshService = freshService;
        }

        public async Task<EmployeeDTO?> GetEmployeeByIdAsync(string ftbId)
        {
            var employee = await _ftbEmpContext.EHremployeeDaily.Where(x => x.NetworkId == ftbId)
                                                              .Select(x => new EmployeeDTO
                                                              {
                                                                  EmployeeId = x.NetworkId,
                                                                  FirstName = x.FirstName,
                                                                  LastName = x.LastName,
                                                                  Email = x.Email
                                                              })
                                                             .FirstOrDefaultAsync();
            return employee;
        }

        public async Task<List<EmployeeDTO>> GetEmployeesBySearchKeyAsync(string searchKey, int maxRecordToFetch)
        {
            var employees = await _ftbEmpContext.EHremployeeDaily.Where(x => x.NetworkId.StartsWith(searchKey)
                                                              || x.LastName.StartsWith(searchKey)
                                                              || x.FirstName.StartsWith(searchKey))
                                                      .Take(maxRecordToFetch)
                                                      .Select(x => new EmployeeDTO
                                                      {
                                                          EmployeeId = x.NetworkId,
                                                          FirstName = x.FirstName,
                                                          LastName = x.LastName,
                                                          Email = x.Email
                                                      })
                                                      .ToListAsync();
            return employees;
        }

        public async Task<List<string>> GetFtbEmailsBySearchKeyAsync(string searchKey, int maxRecordToFetch)
        {
            var employeeEmailsTask = _ftbEmpContext.EHremployeeDaily
                                                    .Where(x => x.Email.Contains(searchKey))
                                                    .Select(x => x.Email)
                                                    .Take(maxRecordToFetch)
                                                    .ToListAsync();

            var groupEmailsTask = _dgContext.DgProperties
                                             .Where(x => x.DgMail.Contains(searchKey))
                                             .Select(x => x.DgMail)
                                             .Take(maxRecordToFetch)
                                             .ToListAsync();

            var freshServiceEmailsTask = _freshService.SearchEmailsAsync(searchKey, maxRecordToFetch);

            await Task.WhenAll(employeeEmailsTask, groupEmailsTask, freshServiceEmailsTask);

            var empEmails = await employeeEmailsTask;
            var groupEmails = await groupEmailsTask;
            var freshServiceEmails = await freshServiceEmailsTask;

            var combine = new HashSet<string>(empEmails, StringComparer.OrdinalIgnoreCase);
            combine.UnionWith(groupEmails);
            combine.UnionWith(freshServiceEmails);

            return combine.Take(maxRecordToFetch).ToList();
        }
    }
}
