﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Settings
{
    public class CyberArkSetting
    {
        public int ApplicationId { get; set; } 
        public Guid CredentialId { get; set; }
    }
}
