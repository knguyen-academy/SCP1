﻿namespace Application.Settings
{
    public class UploadFileSetting
    {
        public List<string> AllowedFileExtensions { get; set; } = new();
        public long MaxFileSize { get; set; } 
    }
}
