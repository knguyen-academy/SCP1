﻿namespace Application.Settings
{
    public class EmailSetting
    {
        public string From { get; set; } = string.Empty;
        public string SOCEmail { get; set; } = string.Empty;
        public string ISOUEmail {  get; set; } = string.Empty;
    }
}
