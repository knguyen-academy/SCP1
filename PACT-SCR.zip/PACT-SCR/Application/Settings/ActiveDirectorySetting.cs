﻿namespace Application.Settings;

public class ActiveDirectorySetting
{
    public string Domain { get; set; } = "ftb.ca.gov";
    public int ApplicationId { get; set; }
    public Guid CredentialId { get; set; }
}