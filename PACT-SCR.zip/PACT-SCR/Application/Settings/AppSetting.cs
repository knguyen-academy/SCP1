﻿namespace Application.Settings
{
    public class AppSetting
    {
        public string FSTicketUrl { get; set; } = string.Empty;
        public string SCPProcedureUrl { get; set; } = string.Empty;
        public string SCPFaqsUrl { get; set; } = string.Empty;
    }
}
