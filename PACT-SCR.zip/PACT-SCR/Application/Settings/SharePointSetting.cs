﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Settings
{
    public class SharePointSetting
    {
        public string TenantId { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        public string SiteUrl { get; set; } = string.Empty;
        public string DriveId { get; set; } = string.Empty;
        public string BasePath {  get; set; } = string.Empty;   
        public string DocumentSegment {  get; set; } = string.Empty;   
        public string MasterFindingSheetFilePath {  get; set; } = string.Empty;

    }
}
