﻿namespace Application.Common.Results
{
    public record Error(string Code, string Message, Exception? Exception =null);
    public class Result
    {
        public bool IsSuccess { get; }
        public Error? Error { get; }

        protected Result(bool success, Error? error)
        {
            IsSuccess = success;
            Error = error;
        }
        public static Result Success() => new Result(true, null);
        public static Result Failure(string code, string message, Exception? ex =null)
            => new Result(false, new Error(code, message, ex));
        public static Result Failure(Error error) => new Result(false, error);
    }

    public sealed class Result<T> : Result
    {
        public T? Value { get; }
        private Result(bool success, T? value, Error? error) : base(success, error) 
        {
            Value = value;
        }
        public static Result<T> Success(T value) => new Result<T>(true, value, null);
        public static Result<T> Failure(string code, string message, Exception? ex = null)
            => new Result<T>(false, default, new Error(code, message, ex));
        public static Result<T> Failure(Error error)
            => new Result<T>(false, default, error);

    }
}
