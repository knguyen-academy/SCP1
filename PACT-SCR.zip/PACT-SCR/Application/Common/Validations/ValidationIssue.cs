﻿namespace Application.Common.Validations
{
    public sealed record ValidationIssue(string PropertyName, string Message);
}
