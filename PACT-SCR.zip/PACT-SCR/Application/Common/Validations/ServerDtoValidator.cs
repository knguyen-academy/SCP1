﻿using Application.DTOs.Request;
using FluentValidation;

namespace Application.Common.Validations
{
    public class ServerDtoValidator : AbstractValidator<ServerDTO>
    {
        public ServerDtoValidator()
        {
            RuleFor(x => x).Custom((dto, ctx) =>
            {
                var issues = ServerDtoRules.Validate(dto);
                foreach (var issue in issues)
                {
                    ctx.AddFailure(issue.PropertyName ?? string.Empty, issue.Message);
                }
            });
        }
    }
}
