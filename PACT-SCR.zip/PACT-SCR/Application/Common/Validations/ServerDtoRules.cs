﻿using Application.Common.Lookups;
using Application.DTOs.Dropdowns;
using Application.DTOs.Request;

namespace Application.Common.Validations
{
    public static class ServerDtoRules
    {
        public static IReadOnlyList<ValidationIssue> Validate(ServerDTO dto)
        {
            var issues = new List<ValidationIssue>();
            if (dto is null)
            {
                issues.Add(new ValidationIssue(string.Empty, "Server is required."));
                return issues;
            }

            // Required booleans/dates
            Require(issues, dto.IsOsPatched, nameof(ServerDTO.IsOsPatched));
            Require(issues, dto.ProductionPlanDate, nameof(ServerDTO.ProductionPlanDate));
            //Require(issues, dto.IsFtiHandle, nameof(ServerDTO.IsFtiHandle));

            // PatchedDate is required only when IsOsPatched == false
            if (dto.IsOsPatched == false)
                Require(issues, dto.PatchedDate, nameof(ServerDTO.PatchedDate));

            // Required strings
            RequireString(issues, dto.Name, nameof(ServerDTO.Name), 255);
            RequireString(issues, dto.CoreFunction, nameof(ServerDTO.CoreFunction), 255);
            RequireString(issues, dto.OsVersion, nameof(ServerDTO.OsVersion), 255);
            RequireString(issues, dto.ServerCustodian, nameof(ServerDTO.ServerCustodian), 255);
            RequireString(issues, dto.BusinessOwner, nameof(ServerDTO.BusinessOwner), 255);

            if (dto.ServerTeams == null || dto.ServerTeams.Count == 0)
            {
                issues.Add(new ValidationIssue(nameof(ServerDTO.ServerTeams), "At least one Application Team is required."));
            }


            // Required dropdowns
            RequireId(issues, dto.EnvironmentId, nameof(ServerDTO.EnvironmentId));
            RequireId(issues, dto.ZoneId, nameof(ServerDTO.ZoneId));
            RequireId(issues, dto.OsId, nameof(ServerDTO.OsId));
            RequireId(issues, dto.DeviceId, nameof(ServerDTO.DeviceId));
            RequireId(issues, dto.HostId, nameof(ServerDTO.HostId));
            RequireId(issues, dto.LifecycleId, nameof(ServerDTO.LifecycleId));
            RequireId(issues, dto.CredentialId, nameof(ServerDTO.CredentialId));

            // IP address: required, length, and must match selected zone pattern.
            if (string.IsNullOrWhiteSpace(dto.IpAddress))
            {
                issues.Add(new ValidationIssue(nameof(ServerDTO.IpAddress), "IP Address is required."));
            }
            else
            {
                if (dto.IpAddress.Length > 15)
                    issues.Add(new ValidationIssue(nameof(ServerDTO.IpAddress), $"IP Address must be at most {15} characters."));

                var selectedZoneValue = dto.SelectedZone?.Value;
                if (string.IsNullOrWhiteSpace(selectedZoneValue) || !IsValidIpForSelectedZone(dto.IpAddress, selectedZoneValue))
                    issues.Add(new ValidationIssue(nameof(ServerDTO.IpAddress), "Not Valid Ip Address."));
            }

            // Conditional fields
            // Imperva agent installed required only for DB/File/Sharepoint server device types.
            if (dto.DeviceId is not null &&
                (dto.DeviceId == (int)DeviceLookup.DatabaseServer
                 || dto.DeviceId == (int)DeviceLookup.FileServer))
                 //|| dto.DeviceId == (int)DeviceLookup.SharepointServer))
            {
                Require(issues, dto.IsImpervaAgentInstalled, nameof(ServerDTO.IsImpervaAgentInstalled));
            }

            // OS other
            if (dto.SelectedOS?.Value == "Other")
                RequireString(issues, dto.OsOther, nameof(ServerDTO.OsOther), 255);

            // Database other (only relevant when database server device selected)
            if (dto.DeviceId == (int)DeviceLookup.DatabaseServer)
            {
                RequireId(issues, dto.DatabaseId, nameof(ServerDTO.DatabaseId));
                if (dto.SelectedDatabase?.Value == "Other")
                    RequireString(issues, dto.DatabaseOther, nameof(ServerDTO.DatabaseOther), 255);
            }

            // Zone IP exception requires Reason + Justification
            if (dto.ZoneId is not null && dto.ZoneId == (int)ZoneIpLookup.Exception)
            {
                RequireString(issues, dto.Reason, nameof(ServerDTO.Reason), 1500);
                RequireString(issues, dto.Justification, nameof(ServerDTO.Justification), 1500);
            }

            // CPR Added / Device Log required (nullable bools)
            Require(issues, dto.IsCpradded, nameof(ServerDTO.IsCpradded));
            Require(issues, dto.IsDeviceLog, nameof(ServerDTO.IsDeviceLog));

            return issues;
        }

        public static IReadOnlyList<ValidationIssue> ValidateProperty(ServerDTO dto, string propertyName)
        {
            var all = Validate(dto);
            return all.Where(x=> string.Equals(x.PropertyName, propertyName, StringComparison.Ordinal)).ToList();
        }

        private static void Require(List<ValidationIssue> issues, bool? value, string propertyName)
        {
            if (value is null)
                issues.Add(new ValidationIssue(propertyName, $"{propertyName} is required."));
        }
        private static void Require(List<ValidationIssue> issues, DateTime? value, string propertyName)
        {
            if (value is null)
                issues.Add(new ValidationIssue(propertyName, $"{propertyName} is required."));
        }

        private static void RequireId(List<ValidationIssue> issues, int? id, string propertyName)
        {
            if (!id.HasValue)
                issues.Add(new ValidationIssue(propertyName, $"{propertyName} is required."));
        }

        private static void RequireString(List<ValidationIssue> issues, string? value, string propertyName, int maxLen)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                issues.Add(new ValidationIssue(propertyName, $"{propertyName} is required."));
                return;
            }

            if (value.Length > maxLen)
                issues.Add(new ValidationIssue(propertyName, $"{propertyName}  must be at most {maxLen} characters."));
        }

        private static bool IsValidIpForSelectedZone(string inputIpAddress, string selectedIpAddress)
        {
            if (string.IsNullOrWhiteSpace(inputIpAddress))
                return false;

            string[] inputIpParts = inputIpAddress.Split('.');
            if (inputIpParts.Length != 4)
                return false;

            foreach (string part in inputIpParts)
            {
                if (!int.TryParse(part, out int num))
                    return false;

                if (num < 0 || num > 255)
                    return false;

                if (part.Length > 1 && part.StartsWith("0"))
                    return false;
            }

            var ipsFromDropdown = selectedIpAddress.Split(new[] { "or" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var ipFromDropdown in ipsFromDropdown)
            {
                if (MatchPatternIp(inputIpParts, ipFromDropdown.Trim()))
                    return true;
            }
            return false;
        }

        private static bool MatchPatternIp(string[] inputIpParts, string ipFromDropdownWithLabel)
        {
            int[] inputIpPartsInNum = inputIpParts.Select(int.Parse).ToArray();
            int colonIndex = ipFromDropdownWithLabel.IndexOf(':');
            string ipFromDropdown = (colonIndex >= 0) ? ipFromDropdownWithLabel[(colonIndex + 1)..].Trim() : ipFromDropdownWithLabel.Trim();

            string[] ipPartsFromDropdown = ipFromDropdown.Split('.');
            if (ipPartsFromDropdown.Length != 4)
                return false;

            for (int i = 0; i < ipPartsFromDropdown.Length; i++)
            {
                string dropdownPart = ipPartsFromDropdown[i].Trim();

                if (dropdownPart.Equals("xxx", StringComparison.OrdinalIgnoreCase))
                    continue;

                if (dropdownPart.Contains('-'))
                {
                    var rangeParts = dropdownPart.Split('-');
                    if (!int.TryParse(rangeParts[0], out int start) || !int.TryParse(rangeParts[1], out int end))
                        return false;

                    if (inputIpPartsInNum[i] < start || inputIpPartsInNum[i] > end)
                        return false;
                }
                else if (dropdownPart.Contains(','))
                {
                    var allowedDigits = dropdownPart.Split(',');
                    bool match = allowedDigits.Any(d => int.TryParse(d.Trim(), out int val) && val == inputIpPartsInNum[i]);
                    if (!match)
                        return false;
                }
                else
                {
                    if (!int.TryParse(dropdownPart, out int exact))
                        return false;

                    if (inputIpPartsInNum[i] != exact)
                        return false;
                }
            }

            return true;
        }
    }
}
