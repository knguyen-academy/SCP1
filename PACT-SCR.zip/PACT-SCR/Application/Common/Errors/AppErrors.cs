﻿using Application.Common.Results;
using Application.DTOs.Attachments;
using System.IO;

namespace Application.Common.Errors
{
    public static class AppErrors
    {
        //ATTACHMENT
        public static Error FileLocked(string fileName) =>
            new("ATTACHMENT_FILE_LOCKED", $"The file '{fileName}' is currently open. Please close it and try again.");
        public static Error AccessDenied(string fileName) =>
            new("ATTACHMENT_ACCESS_DENIED", $"Access denied when deleting '{fileName}'. Please close it and try again, or contact support.");
        public static Error DeleteFailed(string fileName) =>
            new("ATTACHMENT_DELETE_FAILED", $"Failed to delete '{fileName}'. Please try again.");
        public static Error MoveFailed() =>
            new("ATTACHMENT_MOVE_FAILED", $"Failed to move attachments. Please close any open files and try again.");
        public static Error UploadFailed(string fileName) =>
            new("ATTACHMENT_UPLOAD_FAILED", $"Failed to upload '{fileName}'. Please try again.");
        public static Error NoFiles() =>
            new("ATTACHMENT_EMPTY", $"No attachment(s) to upload.");
        public static Error NotAllowedExtension(string fileExtension) =>
            new("ATTACHMENT_EXTENSION_NOT_ALLOWED", $"File Extension not allowed: {fileExtension}");
        public static Error FileTooLarge(long fileSize, long maxFileSize) =>
            new("ATTACHMENT_TOO_LARGE", $"File size {fileSize} exceeds the allowed limit {maxFileSize}");
        public static Error FolderExists(string folderPath) =>
            new("ATTACHMENT_FOLDER_ALREADY_EXISTS.", $"Cannot rename request folder because the destination already exists: {folderPath}");
        public static Error ListFilesFailed() =>
             new("ATTACHMENT_LIST_FAILED.", $"Failed to load attachments. Please try again.");
        public static Error MasterFileNotFound(string path) =>
            new("MASTER_FILE_NOT_FOUND", $"Master file not found at path :{path}");
        public static Error MasterFileCopyFailed(string reason) =>
            new("MASTER_FILE_COPY_FAILED", $"Failed to copy master file: {reason}");

        //REQUEST
        public static Error RequestNotFound(int requestId) =>
            new("REQUEST_NOT_FOUND", $"Request {requestId} was not found. Please refresh and try again.");
        public static Error TicketNotFound(int requestId) =>
            new("TICKET_NOT_FOUND", $"Ticket number is missing for request {requestId}. Please contact admin/dev for further assist.");
        public static Error RequestGroupNotFound(int requestId) =>
            new("REQUEST_GROUP_NOT_FOUND", $"Request group is missing for request {requestId}");

        //SERVER
        public static Error ServerNotFound(int serverId) =>
            new("SERVER_NOT_FOUND", $"Server {serverId} was not found.");
        public static Error ServerNotValid(int serverId) =>
            new("SERVER_VALIDATION", $"Server {serverId} was not found.");
        //IP
        public static Error IpActiveInUse(string serverName) =>
             new("IP_EXISTS", $"IP address is already used by an active server ({serverName})");
        public static Error IpDuplicateInRequest(string ip) =>
           new("IP_DUP", $"Duplicate IP address '{ip}' in this request. Please use a different IP.");
        public static Error ValidationFailed(string message) =>
            new("VALIDATION_FAILED", message);
    }
}
