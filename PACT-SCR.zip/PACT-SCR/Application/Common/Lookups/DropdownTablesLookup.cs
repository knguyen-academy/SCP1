﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Lookups
{
    public enum DropdownTablesLookup
    {
        Environment,
        OperatingSystem,
        GroupName,
        Zone,
        Device,
        Host,
        Lifecycle,
        Credential,
        Database
    }
}
