﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Lookups
{
    public enum AppRole
    {
        [Description("System Admin")]
        SystemAdmin = 1,
        [Description("Admin")]
        Admin = 2,
        [Description("Analyst")]
        Analyst = 3,
        [Description("User")]
        User = 4,
    }
}
