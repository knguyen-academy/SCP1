﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Lookups
{
    public enum StatusLookup
    {
      Open =1,
      Closed=2,
      Cancelled=3,
      Pending=4
    }
}
