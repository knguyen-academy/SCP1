﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Lookups
{
    public enum DeviceLookup
    {
        DatabaseServer = 30,
        FileServer = 50,
        //SharepointServer = 40
    }
}
