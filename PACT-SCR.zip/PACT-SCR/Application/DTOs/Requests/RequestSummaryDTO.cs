﻿namespace Application.DTOs.Request
{
    public class RequestSummaryDTO
    {
        public int Id {get; set;}
        public string GroupName { get; set; }
        public string FtbId { get; set; }
        public string RequesterFirstName{ get; set; }
        public string RequesterLastName{ get; set; }
        public string TicketNumber {  get; set; }
        public string DeviceNames { get; set; }
        public DateTime RequestDate { get; set; }
        public DateTime? CloseDate { get; set; }
        public string Status { get; set; }
        public string AdminNote { get; set; }
        public List<string> ServerTeams { get; set; } = new();
        public string FullName
        {
            get
            {
                return $"{RequesterLastName}, {RequesterFirstName} ({FtbId})";
            }
        }

    }
}
