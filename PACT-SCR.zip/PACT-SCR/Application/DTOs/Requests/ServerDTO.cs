﻿using Application.DTOs.Dropdowns;
using Application.DTOs.Employees;

namespace Application.DTOs.Request
{
    public class ServerDTO
    {
        public Guid ClientId { get; set; } = Guid.NewGuid();
        public int RequestId { get; set; }
        public int? ServerId { get; set; } 
        public string Name { get; set; }
        public string IpAddress { get; set; }
        public int? OsId { get; set; }
        public string OsVersion { get; set; }
        public int? EnvironmentId { get; set; }
        public int? DatabaseId { get; set; }
        public int? DeviceId { get; set; }
        public int? CredentialId { get; set; }
        public int? ZoneId { get; set; }
        public bool? IsOsPatched { get; set; }
        public int? HostId { get; set; }
        public int? LifecycleId { get; set; }
        public string CoreFunction { get; set; }
        public bool? IsCpradded { get; set; }
        public bool? IsImpervaAgentInstalled { get; set; }
        public DateTime? PatchedDate { get; set; }
        public bool? IsTripwireAgentInstallled { get; set; }
        public bool? IsDeviceLog { get; set; }
        public string Reason { get; set; }
        public string Justification { get; set; }
        public bool? IsCrowstrikeInstalled { get; set; } = false;
        public bool? IsBigFixAgentInstalled { get; set; } = false;
        public bool? IsSnowAtlasAgentInstalled { get; set; } = false;
        public bool? IsSplunkForwarderInstalled { get; set; } = false;
        public bool? IsFtiHandle { get; set; }
        public string OsOther { get; set; }
        public DateTime? ProductionPlanDate { get; set; }
        public string WorkStationZone { get; set; }
        public bool? IsActive { get; set; }
        public string DatabaseOther { get; set; }
        public string ServerCustodian { get; set; }
        public string BusinessOwner { get; set; }
        public List<string> ServerTeams { get; set; } = new();
        public string ServerTeamSearch { get; set; }
        public List<DropdownLookupDTO> OsList { get; set; } = new();
        public List<DropdownLookupDTO> EnvironmentList { get; set; } = new();
        public List<DropdownLookupDTO> ZoneList { get; set; } = new();
        public List<DropdownLookupDTO> DeviceList { get; set; } = new();
        public List<DropdownLookupDTO> HostList { get; set; } = new();
        public List<DropdownLookupDTO> LifecycleList { get; set; } = new();
        public List<DropdownLookupDTO> CredentialList { get; set; } = new();
        public List<DropdownLookupDTO> DatabaseList { get; set; } = new();
        public DropdownLookupDTO? SelectedOS => OsId is null ? null : OsList.FirstOrDefault(x=>x.Id == OsId);
        public DropdownLookupDTO? SelectedEnvironment => EnvironmentId is null ? null : EnvironmentList.FirstOrDefault(x=>x.Id == EnvironmentId);
        public DropdownLookupDTO? SelectedZone => ZoneId is null ? null : ZoneList.FirstOrDefault(x=>x.Id == ZoneId);
        public DropdownLookupDTO? SelectedDevice  => DeviceId is null ? null : DeviceList.FirstOrDefault(x=> x.Id == DeviceId); 
        public DropdownLookupDTO? SelectedHost => HostId is null ? null : HostList.FirstOrDefault(x=> x.Id == HostId);
        public DropdownLookupDTO? SelectedLifecycle => LifecycleId is null ? null : LifecycleList.FirstOrDefault(x => x.Id == LifecycleId);
        public DropdownLookupDTO? SelectedCredential => CredentialId is null ? null : CredentialList.FirstOrDefault(x=>x.Id == CredentialId);
        public DropdownLookupDTO? SelectedDatabase => DatabaseId is null ? null : DatabaseList.FirstOrDefault( x=> x.Id == DatabaseId);

        public Func<EmployeeDTO?, string> EmployeeDTOToString = (EmployeeDTO? emp) =>
        {
            if (emp is null)
            {
                return string.Empty;
            }

            return $"{emp.LastName}, {emp.FirstName} ({emp.EmployeeId})";
        };
    }
}
