﻿using Application.DTOs.Dropdowns;

namespace Application.DTOs.Dropdowns
{
    public class AllDropdownDataDTO
    {
        public List<DropdownLookupDTO> Environments { get; set; } = new();
        public List<DropdownLookupDTO> Zones { get; set; } = new();
        public List<DropdownLookupDTO> Os { get; set; } = new();
        public List<DropdownLookupDTO> Devices { get; set; } = new();
        public List<DropdownLookupDTO> Hosts { get; set; } = new();
        public List<DropdownLookupDTO> LifeCycles { get; set; } = new();
        public List<DropdownLookupDTO> Credentials { get; set; } = new();
        public List<DropdownLookupDTO> Databases { get; set; } = new();

    }
}
