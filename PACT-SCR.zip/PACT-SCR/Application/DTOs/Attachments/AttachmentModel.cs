﻿using Application.Common.Lookups;

namespace Application.DTOs.Attachments
{
    public class AttachmentModel
    {
        public string Name { get; set; }
        public long Size { get; set; }
        public byte[] Content { get; set; } 
        public string FilePath { get; set; }
        public AttachmentStatus Status { get; set; } = AttachmentStatus.Pending;
    }
}
