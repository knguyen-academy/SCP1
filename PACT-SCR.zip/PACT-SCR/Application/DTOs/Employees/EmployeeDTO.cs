﻿namespace Application.DTOs.Employees
{
    public class EmployeeDTO
    {
        public string EmployeeId { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string? Email { get; set; }
        public string FullName
        {
            get
            {
                return $"{LastName}, {FirstName} ({EmployeeId})";
            }
        }
    }
}
