﻿namespace Application.DTOs.Employees;

public enum RecipientType
{
    Unknown,
    Individual,
    DistributionGroup,
    SharedMailbox
}

public sealed record ContactOptionDTO(
    string DirectoryId,
    string DisplayName,
    string Email,
    RecipientType Type);