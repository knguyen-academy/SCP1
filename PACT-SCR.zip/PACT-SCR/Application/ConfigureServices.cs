﻿using Application.Common.Validations;
using Application.DTOs.Request;
using Application.Features.Requests.Commands;
using Application.Features.Requests.Queries;
using Application.Features.Servers.Commands;
using Application.Features.Servers.Queries;
using Application.Security.Interface;
using Application.Services.Attachment;
using Application.Services.CyberArk;
using Application.Services.Directory;
using Application.Services.DropdownLookup;
using Application.Services.Email;
using Application.Services.FreshServices;
using Application.Services.FtbEmployee;
using Application.Services.Servers;
using Application.Services.UserGroup;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using Package;

namespace Application
{
    public static class ConfigureServices
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services, string environmentName)
        {
            services.AddTransient<IValidator<ServerDTO>, ServerDtoValidator>();
            services.AddTransient<IValidator<CreateRequestCommandData>, CreateRequestCommandDataValidator>();
            services.AddTransient<IAttachmentService, SharePointAttachmentService>();
            services.AddTransient<CyberArkService>();
            services.AddTransient<ActiveDirectoryClientFactory>();
            services.AddTransient<ADGroupLookupService>();
            services.AddTransient<UserGroupService>();
            services.AddTransient<FtbEmployeeService>();
            services.AddTransient<ServerService>(); 
            services.AddTransient<IDropdownLookupService, DropdownLookupService>();
            services.AddTransient<CreateRequestCommand>();
            services.AddTransient<CertifyRequestCommand>();
            services.AddTransient<UpdateRequestNoteCommand>();
            services.AddTransient<CancelRequestCommand>();
            services.AddTransient<GetAllRequestsQuery>();
            services.AddTransient<GetAllServersByRequestIdQuery>();
            services.AddTransient<GetServerByIdQuery>();
            services.AddTransient<UpdateServerCommand>();
            services.AddTransient<IFreshService, FreshService>();
            services.AddTransient<SOCEmailService>();
            services.AddTransient<ISecurityService, SecurityService>();

            if (environmentName.ToUpper() == "PRODUCTION")
            {
                services.AddProxyServices("Production", "BD237D1B-7AC6-483D-B21C-563614884FCE");
            }
            else
            {
                services.AddProxyServices("Development", "C648DC72-A7E8-4FFF-842E-4992BA899A7E");
            }
            return services;

        }
        public static IServiceCollection AddApplicationServicesForApi(this IServiceCollection services, string environmentName)
        {
            services.AddTransient<IValidator<ServerDTO>, ServerDtoValidator>();

            services.AddTransient<GetAllRequestsQuery>();
            services.AddTransient<GetAllServersByRequestIdQuery>();
            services.AddTransient<GetServerByIdQuery>();

            services.AddTransient<UpdateServerCommand>();

            //services.AddTransient<UserGroupService>();
            services.AddTransient<ServerService>();
            services.AddTransient<ISecurityService, SecurityService>();
            return services;
        }
    }
}
