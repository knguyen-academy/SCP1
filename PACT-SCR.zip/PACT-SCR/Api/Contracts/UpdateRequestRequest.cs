﻿using Application.Common.Lookups;
using System.ComponentModel.DataAnnotations;

namespace Api.Contracts
{
    public sealed class UpdateRequestRequest
    {
        [StringLength(1000)]
        public string? AdminNote {  get; set; }

        [Range((int)StatusLookup.Open, (int)StatusLookup.Pending)]
        public int? StatusId { get; set; }

        public DateTime? CloseDate { get; set; }
    }
}
