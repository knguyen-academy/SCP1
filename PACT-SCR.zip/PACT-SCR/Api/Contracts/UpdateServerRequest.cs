﻿namespace Api.Contracts
{
    public class UpdateServerRequest
    {
    }
}
