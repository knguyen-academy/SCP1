﻿using Application.Features.Servers.Queries;
using Application.Persistence.SCR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers
{
    [Authorize(Policy = "Admin")]
    [ApiController]
    [Route("api/[controller]")]
    public class ServersController : ControllerBase
    {
        private readonly SCRContext _db;

        public ServersController(SCRContext db)
        {
            _db = db; 
        }

        [HttpGet("api/requests/{requestId:int}/servers")]
        public async Task<IActionResult> GetByRequestId([FromRoute] int requestId, CancellationToken ct)
        {
            var result = await _db.Server.Where(x => x.RequestId == requestId).ToListAsync(ct);
            return Ok(result);
        }

        [HttpGet("api/servers/{id:int}")]
        public async Task<IActionResult> GetById([FromRoute] int id, CancellationToken ct)
        {
            var result = await _db.Server.FirstOrDefaultAsync(x => x.Id == id, ct);
            if (result is null)
                return NotFound();
            return Ok(result);
        }
    }
}
