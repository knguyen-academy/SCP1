﻿using Api.Contracts;
using Application.Common.Lookups;
using Application.Persistence.SCR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using Serilog.Context;

namespace Api.Controllers
{

    [Authorize(Policy = "Admin")]
    [ApiController]
    [Route("api/[controller]")]
    public class RequestsController : ControllerBase
    {
    
        private readonly SCRContext _db;
        private readonly ILogger<RequestsController> _logger;
        public RequestsController(
                                  SCRContext db,
                                  ILogger<RequestsController> logger
            )
        {
     
            _db = db;
            _logger = logger;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet("throw")]
        public IActionResult Throw()
        {
            throw new InvalidOperationException("Global exp middleware test.");
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet("whoami")]
        public IActionResult WhoAmI()
        {
            var identity = User?.Identity;
            return Ok(new
            {
                IsAuthenticated = identity?.IsAuthenticated ?? false,
                Name = identity?.Name,
                AuthType = identity?.AuthenticationType,
                Claims = User?.Claims.Select(c => new { c.Type, c.Value })
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetAll(CancellationToken ct)
        {
            var result = await _db.CertificationRequest.AsNoTracking().ToListAsync(ct);
            return Ok(result);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById([FromRoute] int id, CancellationToken ct)
        {
            var result = await _db.CertificationRequest.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, ct);
            if (result is null)
                return NotFound();
            return Ok(result);
        }

        [Authorize(Policy ="WriteAccess")]
        [HttpPatch("{id:int}")]
        public async Task<IActionResult> Update(
            [FromRoute] int id,
            [FromBody] UpdateRequestRequest body,
            CancellationToken ct)
        {
            var request = await _db.CertificationRequest.FirstOrDefaultAsync(x=> x.Id == id, ct);
            if(request is null)
                return NotFound();

            if(body.AdminNote is not null)
                request.AdminNote = body.AdminNote;

            if(body.StatusId.HasValue)
                request.StatusId = body.StatusId.Value;

            var requestStatus  = body.StatusId.Value;

            //if update to cancel
            if(requestStatus == (int)StatusLookup.Cancelled)
            {
                if (request.Server is not null)
                {
                    foreach (var server in request.Server)
                    {
                        server.IsActive = false;
                    }
                }
            }
    
            if (body.CloseDate.HasValue)
            {
                if (request.StatusId == (int)StatusLookup.Closed || request.StatusId == (int)StatusLookup.Cancelled)
                    request.CloseDate = body.CloseDate.Value;
            }

            await _db.SaveChangesAsync(ct);

            using (LogContext.PushProperty("UserName", User?.Identity?.Name))
            using (LogContext.PushProperty("RequestId", request.Id))
            {
                _logger.LogInformation("Request Updated via API. RequestId={RequestId} User={User} StatusId={StatusId}", request.Id, User?.Identity?.Name, request.StatusId);
            }
            return Ok(new
            {
                request.Id,
                request.StatusId,
                request.AdminNote,
                request.CloseDate
            });

        }

        [Authorize(Policy = "WriteAccess")]
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete([FromRoute] int id, CancellationToken ct)
        {
            var request = await _db.CertificationRequest
                                   .Include(x => x.Server)
                                   .FirstOrDefaultAsync(x => x.Id == id, ct);
            if (request is null)
                return NotFound();

            request.StatusId = (int)StatusLookup.Cancelled;
            request.CloseDate ??= DateTime.UtcNow;

            if(request.Server is not null)
            {
                foreach(var server in request.Server)
                {
                    server.IsActive = false;
                }
            }
            await _db.SaveChangesAsync(ct);

            using (LogContext.PushProperty("UserName", User?.Identity?.Name))
            using (LogContext.PushProperty("RequestId", request.Id))
            {
                _logger.LogInformation("Request deleted via API. RequestId={RequestId} User={User} StatusId={StatusId}", request.Id, User?.Identity?.Name, request.StatusId);
            }
            return NoContent();
        }
    }
}

