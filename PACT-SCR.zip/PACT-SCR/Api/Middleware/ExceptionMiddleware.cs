﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace Api.Middleware
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionMiddleware> _logger;
        public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                var traceId = Activity.Current?.Id ?? context.TraceIdentifier;
                var correlationId = context.Request.Headers["X-Correlation-ID"].FirstOrDefault()
                                   ?? context.Response.Headers["X-Correlation-ID"].FirstOrDefault();

                _logger.LogError(
                    ex,
                    "Unhandled exception. TraceId={TraceId}, CorrelationId={CorrelationId}, Path={Path}, Method={Method}",
                    traceId,
                    correlationId,
                    context.Request.Path.Value,
                    context.Request.Method);

                if (context.Response.HasStarted)
                    throw;
                context.Response.Clear();
                context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                context.Response.ContentType = "application/problem+json";

                var problem = new ProblemDetails
                {
                    Title = "An unexpected error occurred",
                    Status = StatusCodes.Status500InternalServerError,
                    Detail = "Please try again. If the problem persists, contact support and provide the TraceId.",
                    Instance = context.Request.Path
                };

                problem.Extensions["traceId"] = traceId;
                if(!string.IsNullOrWhiteSpace(correlationId))
                    problem.Extensions["correlationId"] = correlationId;

                await context.Response.WriteAsJsonAsync(problem);
            }
        }
    }
}
