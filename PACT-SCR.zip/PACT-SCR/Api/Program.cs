using Api.Middleware;
using Application;
using Application.Persistence.FTBEmployee;
using Application.Persistence.SCR;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using Polly;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.MSSqlServer;
using System.Collections.ObjectModel;
using System.Data;
using System.Text.Json.Serialization;


var builder = WebApplication.CreateBuilder(args);
var configuration = builder.Configuration;
var environment = builder.Environment;
// Add services to the container.
builder.Host.UseSerilog((ctx, services, lc) =>
{
    var columnOptions = new ColumnOptions
    {
        AdditionalColumns = new Collection<SqlColumn>
        {
            new SqlColumn("UserName", SqlDbType.NVarChar) {DataLength = 256},
            new SqlColumn("CorrelationId", SqlDbType.NVarChar) {DataLength = 256},
            new SqlColumn("RequestPath", SqlDbType.NVarChar) {DataLength = 512},
            new SqlColumn("HttpMethod", SqlDbType.NVarChar) {DataLength = 10},
            new SqlColumn("StatusCode", SqlDbType.Int),
            new SqlColumn("RequestId", SqlDbType.Int),
            new SqlColumn("ServerId", SqlDbType.Int),
        }
    };

    columnOptions.Store.Remove(StandardColumn.LogEvent);
    lc.MinimumLevel.Information()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
    .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
    .Enrich.FromLogContext()
    .Enrich.WithMachineName()
    .Enrich.WithProcessId()
    .Enrich.WithThreadId()
    .WriteTo.MSSqlServer(connectionString: ctx.Configuration.GetConnectionString("AppConnectionString"),
    sinkOptions: new MSSqlServerSinkOptions
    {
        SchemaName = "SCR",
        TableName = "ApiLogs",
        AutoCreateSqlDatabase = false
    },
    columnOptions: columnOptions
    );
});
builder.Services.AddControllers()
    .AddJsonOptions(option =>
    {
        option.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    });
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<SCRContext>(options =>
{
    if (environment.IsDevelopment())
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString")).EnableSensitiveDataLogging();
    }
    else
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString"));
    }
}, ServiceLifetime.Transient, ServiceLifetime.Transient);


builder.Services.AddDbContext<FTBEmployeeContext>(options =>
{
    if (environment.IsDevelopment())
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString")).EnableSensitiveDataLogging();
    }
    else
    {
        options.UseSqlServer(configuration.GetConnectionString("AppConnectionString"));
    }
}, ServiceLifetime.Transient, ServiceLifetime.Transient);

builder.Services.AddApplicationServicesForApi(builder.Environment.EnvironmentName);

var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>();
if (allowedOrigins is { Length: > 0 })
{
    builder.Services.AddCors(options =>
    {
        options.AddPolicy("DefaultCors", policy =>
        {
            policy.WithOrigins(allowedOrigins)
                     .AllowAnyHeader()
                     .AllowAnyMethod()
                     .AllowCredentials();
        });
    });
}

builder.Services
       .AddAuthentication(NegotiateDefaults.AuthenticationScheme)
       .AddNegotiate();

builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
                                .RequireAuthenticatedUser()
                                .Build();

    options.AddPolicy("SystemAdmin", p => p.RequireRole("Config Mgmt Admins GG"));
    options.AddPolicy("Admin", p => p.RequireRole("SOC", "Config Mgmt Admins GG"));
    options.AddPolicy("WriteAccess", p => p.RequireRole("SOC", "Config Mgmt Admins GG"));
});

builder.Services.AddHealthChecks().AddDbContextCheck<SCRContext>("SCR-db");

builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;

    options.KnownNetworks.Clear();
    options.KnownProxies.Clear();
});


var app = builder.Build();

app.UseMiddleware<ExceptionMiddleware>();
app.UseMiddleware<CorrelationIdMiddleware>();
app.UseSerilogRequestLogging(options =>
{
    options.EnrichDiagnosticContext = (diag, http) =>
    {
        diag.Set("RequestHost", http.Request.Host.Value);
        diag.Set("RequestScheme", http.Request.Scheme);
        diag.Set("RequestPath", http.Request.Path.Value);
        diag.Set("QueryString", http.Request.QueryString.Value);
        diag.Set("HttpMethod", http.Request.Method);
        diag.Set("TraceId", http.TraceIdentifier);
        var correlationId = http.Request.Headers["X-Correlation-ID"].FirstOrDefault()
                             ?? http.Response.Headers["X-Correlation-ID"].FirstOrDefault();
        if (!string.IsNullOrWhiteSpace(correlationId))
            diag.Set("CorrelationId", correlationId);

        var userName = http?.User?.Identity?.IsAuthenticated == true ? http.User.Identity!.Name : null;
        if (!string.IsNullOrWhiteSpace(userName))
            diag.Set("UserName", userName);
    };
});

app.Use(async (ctx, next) =>
    {
        ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
        ctx.Response.Headers["X-Frame-Options"] = "DENY";
        ctx.Response.Headers["Referrer-Policy"] = "no-referrer";
        await next();
    });


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    //app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI(c => { c.DefaultModelExpandDepth(-1); });
}

app.UseForwardedHeaders();
var pathBase = builder.Configuration["PathBase"];
if (!string.IsNullOrWhiteSpace(pathBase))
{
    if (!pathBase.StartsWith("/"))
        pathBase = "/" + pathBase;

    app.UsePathBase(pathBase);
}
app.UseHttpsRedirection();
app.UseCors("Default");

app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health").AllowAnonymous();
app.Run();
